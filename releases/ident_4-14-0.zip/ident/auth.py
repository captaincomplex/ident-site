"""Optional username/password protection for the web control panel.

Off by default: with no password set the panel behaves exactly as before, so a
fresh install on your home network needs no configuration. Set a password (from
the panel, or `python -m ident.main --set-password`) and every page then
requires a login.

Passwords are stored only as a salted PBKDF2-SHA256 hash. The session cookie is
signed with a secret key generated once and kept in the data directory.

NOTE: over plain HTTP a password crosses the network in the clear. On your own
LAN that's normally fine; if you expose the panel to the internet, put it behind
HTTPS (e.g. a Cloudflare Tunnel) rather than forwarding port 8080 directly.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import os
import secrets

_ITERATIONS = 120_000


# ---------- password hashing ----------

def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, _ITERATIONS)
    return "pbkdf2_sha256${}${}${}".format(
        _ITERATIONS, base64.b64encode(salt).decode(), base64.b64encode(dk).decode())


def verify_password(password: str, stored: str) -> bool:
    try:
        algo, iters, salt_b64, hash_b64 = stored.split("$")
        if algo != "pbkdf2_sha256":
            return False
        dk = hashlib.pbkdf2_hmac("sha256", password.encode(),
                                 base64.b64decode(salt_b64), int(iters))
        return hmac.compare_digest(dk, base64.b64decode(hash_b64))
    except Exception:
        return False


# ---------- signing key for session cookies ----------

def secret_key() -> bytes:
    from .config import DATA_DIR
    path = os.path.join(DATA_DIR, "secret.key")
    if os.path.exists(path):
        try:
            data = open(path, "rb").read().strip()
            if data:
                return data
        except Exception:
            pass
    os.makedirs(DATA_DIR, exist_ok=True)
    key = secrets.token_bytes(32)
    with open(path, "wb") as f:
        f.write(key)
    try:
        os.chmod(path, 0o600)
    except Exception:
        pass
    return key


# ---------- brute-force throttling ----------

_ATTEMPTS: dict[str, list[float]] = {}
MAX_ATTEMPTS = 8          # failures allowed inside the window
WINDOW_SECONDS = 900      # 15 minutes


def _prune(key: str, now: float) -> list[float]:
    kept = [t for t in _ATTEMPTS.get(key, []) if now - t < WINDOW_SECONDS]
    if kept:
        _ATTEMPTS[key] = kept
    else:
        _ATTEMPTS.pop(key, None)
    return kept


def lockout_remaining(key: str) -> int:
    """Seconds until this client may try again; 0 if it may try now."""
    import time
    now = time.time()
    tries = _prune(key, now)
    if len(tries) < MAX_ATTEMPTS:
        return 0
    return max(0, int(WINDOW_SECONDS - (now - min(tries))))


def record_failure(key: str) -> None:
    import time
    now = time.time()
    _prune(key, now)
    _ATTEMPTS.setdefault(key, []).append(now)


def clear_attempts(key: str) -> None:
    _ATTEMPTS.pop(key, None)


# ---------- helpers ----------

def is_enabled(cfg) -> bool:
    return bool(getattr(cfg, "auth_password_hash", ""))


# `auth_trust_lan` used to let a caller from a private address skip the login.
# It was removed in v4.13.0: behind the Cloudflare tunnel the FAQ recommends,
# every request from the public internet arrives from 127.0.0.1, so "trust the
# local network" quietly meant "trust everyone".


# ---------- locked out? ----------

# A customer who forgets the panel password has no way back in through the
# panel itself, and telling a pilot to SSH into a Raspberry Pi is not a support
# answer. So: put a file called `ident-reset.txt` on the SD card's boot
# partition — which any computer can read, no terminal needed — and the next
# time the display starts it clears the password and deletes the file. The card
# has to come out of the device, so it needs physical possession, which is a
# reasonable bar for a wall display in someone's kitchen.
RESET_FILENAME = "ident-reset.txt"
RESET_LOCATIONS = ("/boot/firmware", "/boot")


def _reset_markers():
    from .config import DATA_DIR
    return [os.path.join(d, RESET_FILENAME) for d in (*RESET_LOCATIONS, DATA_DIR)]


def check_password_reset(cfg) -> bool:
    """Clear the panel password if a reset marker is present. Returns True if it did."""
    found = [p for p in _reset_markers() if os.path.exists(p)]
    if not found:
        return False
    cfg.auth_password_hash = ""
    cfg.auth_epoch = int(getattr(cfg, "auth_epoch", 0) or 0) + 1
    cfg.save()
    for p in found:
        try:
            os.remove(p)
        except OSError as e:
            print(f"[ident] password cleared, but {p} could not be removed ({e}) — "
                  "delete it or the password will be cleared again on every boot")
    print("[ident] password reset requested from the SD card; the panel is open. "
          "Set a new password now.")
    return True


def check(cfg, username: str, password: str) -> bool:
    want_user = (getattr(cfg, "auth_user", "") or "").strip()
    if want_user and (username or "").strip() != want_user:
        return False
    return verify_password(password or "", getattr(cfg, "auth_password_hash", ""))
