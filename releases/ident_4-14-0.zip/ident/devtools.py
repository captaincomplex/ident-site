"""Developer tools: put the wall into any duty state on demand.

Two jobs.

1. Preview. Pick a duty code and the panel behaves as though the pilot were in
   the middle of it, right now. Checking that ADTY looks right shouldn't mean
   waiting until you're next on airport standby.

2. Onboarding a new airline. Paste a calendar event, or a whole .ics, and see
   exactly how the parser classifies it. That is the loop for turning a
   submitted sample roster into working support, and it is much faster than
   editing keyword lists and hoping.

The override is written to a file with an expiry rather than held in memory:
the web panel and the display loop are different threads, and a forgotten
simulation must not leave someone's wall showing a fictional duty forever.
"""
from __future__ import annotations

import datetime as dt
import json
import os
import time
from typing import Optional

from .models import Duty, DutyType, Roster, Sector

OVERRIDE_NAME = "dev_override.json"
MAX_MINUTES = 60                      # a simulation can never outlive this


# --------------------------------------------------------------------------
# scenarios
# --------------------------------------------------------------------------

def _utc(y, m, d, hh, mm):
    return dt.datetime(y, m, d, hh, mm, tzinfo=dt.timezone.utc)


def _today(now: dt.datetime):
    return now.date()


def _sec(no, dep, arr, std, sta):
    return Sector(flight_no=no, dep=dep, arr=arr, std=std, sta=sta)


def _fly(day, report, sectors, base="LGW", **kw):
    return Duty(date=day, duty_type=DutyType.FLY, raw_code="FLY",
                report=report, duty_end=sectors[-1].sta, sectors=sectors, **kw)


def _off(day, code="D/O"):
    return Duty(date=day, duty_type=DutyType.DAY_OFF, raw_code=code)


def _standby(day, start, end, code="ADTY"):
    return Duty(date=day, duty_type=DutyType.STANDBY, raw_code=code,
                standby_start=start, standby_end=end)


def _training(day, report, end, code="SIM"):
    return Duty(date=day, duty_type=DutyType.TRAINING, raw_code=code,
                report=report, duty_end=end)


def _next_day_duty(now, base="LGW"):
    """A duty tomorrow, so day-off screens have something to point at."""
    d = _today(now) + dt.timedelta(days=1)
    r = _utc(d.year, d.month, d.day, 5, 10)
    return _fly(d, r, [_sec("8243", base, "NTE", _utc(d.year, d.month, d.day, 6, 10),
                            _utc(d.year, d.month, d.day, 8, 25)),
                       _sec("8244", "NTE", base, _utc(d.year, d.month, d.day, 9, 5),
                            _utc(d.year, d.month, d.day, 11, 20))])


def _build(key: str, now: dt.datetime, base: str = "LGW"):
    """Return (roster, now) with the scenario happening at `now`."""
    d = _today(now)
    Y, M, D = d.year, d.month, d.day
    t = lambda hh, mm: _utc(Y, M, D, hh, mm)

    if key == "in_flight":
        duty = _fly(d, t(5, 10), [_sec("8243", base, "NTE", t(6, 10), t(8, 25)),
                                  _sec("8244", "NTE", base, t(9, 5), t(11, 20))])
        return Roster(base=base, duties=[duty]), t(7, 20)

    if key == "pre_flight":
        duty = _fly(d, t(5, 10), [_sec("8243", base, "NTE", t(6, 10), t(8, 25))])
        return Roster(base=base, duties=[duty]), t(5, 40)

    if key == "before_report":
        duty = _fly(d, t(5, 10), [_sec("8243", base, "NTE", t(6, 10), t(8, 25))])
        return Roster(base=base, duties=[duty]), t(2, 30)

    if key == "turnaround":
        duty = _fly(d, t(5, 10), [_sec("8243", base, "NTE", t(6, 10), t(8, 25)),
                                  _sec("8244", "NTE", base, t(9, 5), t(11, 20))])
        return Roster(base=base, duties=[duty]), t(8, 45)

    if key == "post_duty":
        duty = _fly(d, t(5, 10), [_sec("8243", base, "NTE", t(6, 10), t(8, 25))])
        return Roster(base=base, duties=[duty, _off(d + dt.timedelta(days=1))]), t(8, 40)

    if key == "multi_sector":
        duty = _fly(d, t(4, 40), [
            _sec("8201", base, "NTE", t(5, 40), t(7, 30)),
            _sec("8202", "NTE", base, t(8, 10), t(10, 0)),
            _sec("8455", base, "BOD", t(10, 50), t(12, 40)),
            _sec("8456", "BOD", base, t(13, 20), t(15, 10))])
        return Roster(base=base, duties=[duty]), t(6, 30)

    if key == "adty":
        return Roster(base=base, duties=[
            _standby(d, t(5, 0), t(13, 0), "ADTY"),
            _next_day_duty(now, base)]), t(8, 30)

    if key == "esby":
        return Roster(base=base, duties=[
            _standby(d, t(6, 0), t(18, 0), "ESBY"),
            _next_day_duty(now, base)]), t(11, 0)

    if key == "standby_later":
        return Roster(base=base, duties=[_standby(d, t(16, 0), t(23, 0), "LSBY")]), t(9, 0)

    if key == "day_off":
        return Roster(base=base, duties=[_off(d), _next_day_duty(now, base)]), t(19, 30)

    if key == "wftu":
        return Roster(base=base, duties=[_off(d, "WFTU"), _next_day_duty(now, base)]), t(11, 0)

    if key == "leave":
        return Roster(base=base, duties=[_off(d, "ANNUAL LEAVE")]), t(11, 0)

    if key == "training":
        return Roster(base=base, duties=[_training(d, t(8, 0), t(16, 0), "SIM")]), t(11, 0)

    if key == "positioning":
        pos = Duty(date=d, duty_type=DutyType.FLY, raw_code="PERSONAL",
                   personal=True, airline="KL", report=t(3, 30), duty_end=t(6, 10),
                   sectors=[_sec("1007", "AMS", base, t(5, 0), t(6, 10))])
        work = _fly(d, t(7, 30), [_sec("8243", base, "NTE", t(8, 30), t(10, 10))])
        return Roster(base=base, duties=[pos, work]), t(5, 30)

    if key == "delayed":
        # Same duty, but the return sector has slipped two hours.
        duty = _fly(d, t(5, 10), [_sec("8243", base, "NTE", t(6, 10), t(8, 25)),
                                  _sec("8244", "NTE", base, t(11, 5), t(13, 20))])
        return Roster(base=base, duties=[duty]), t(9, 30)

    if key == "no_roster":
        return Roster(base=base, duties=[]), now

    raise KeyError(key)


# label, key, what it is meant to prove
SCENARIOS = [
    ("Airborne",                 "in_flight",     "Mid-sector, outbound"),
    ("Reported, not departed",   "pre_flight",    "On stand before the first flight"),
    ("Counting down to report",  "before_report", "Hours before the duty starts"),
    ("Turnaround",               "turnaround",    "Down the back end, next departure showing"),
    ("Heading home",             "post_duty",     "After chocks — debrief, walk, commute"),
    ("Four-sector day",          "multi_sector",  "All destinations, not just the first"),
    ("Delayed return",           "delayed",       "Landing and home times slipped"),
    ("ADTY — airport standby",   "adty",          "Mid airport duty at base"),
    ("ESBY — home standby",      "esby",          "Mid home standby"),
    ("Standby later today",      "standby_later", "Counting down to a standby window"),
    ("Day off",                  "day_off",       "With the next duty underneath"),
    ("WFTU",                     "wftu",          "Must read as a day off"),
    ("Annual leave",             "leave",         "Day off, different code"),
    ("Training / SIM",           "training",      "Non-flying duty"),
    ("Positioning flight",       "positioning",   "Commuter's own flight into base"),
    ("No roster",                "no_roster",     "Empty state"),
]

SCENARIO_KEYS = [k for _l, k, _d in SCENARIOS]


def build(key: str, base: str = "LGW", now: Optional[dt.datetime] = None):
    now = now or dt.datetime.now(dt.timezone.utc)
    return _build(key, now, base or "LGW")


# --------------------------------------------------------------------------
# the override file
# --------------------------------------------------------------------------

def _path() -> str:
    from .config import DATA_DIR
    return os.path.join(DATA_DIR, OVERRIDE_NAME)


def set_override(key: str, minutes: int = 15) -> dict:
    if key not in SCENARIO_KEYS:
        raise KeyError(key)
    minutes = max(1, min(MAX_MINUTES, int(minutes or 15)))
    data = {"scenario": key, "until": time.time() + minutes * 60,
            "set_at": dt.datetime.now(dt.timezone.utc).isoformat()}
    from .config import DATA_DIR
    os.makedirs(DATA_DIR, exist_ok=True)
    tmp = _path() + ".tmp"
    with open(tmp, "w") as f:
        json.dump(data, f)
    os.replace(tmp, _path())
    return data


def clear_override() -> None:
    try:
        os.remove(_path())
    except FileNotFoundError:
        pass


def get_override() -> Optional[dict]:
    """The active override, or None. Expired files are removed as we go."""
    try:
        with open(_path()) as f:
            data = json.load(f)
    except (FileNotFoundError, ValueError):
        return None
    if float(data.get("until", 0)) < time.time():
        clear_override()
        return None
    if data.get("scenario") not in SCENARIO_KEYS:
        clear_override()
        return None
    data["seconds_left"] = int(float(data["until"]) - time.time())
    return data


def override_view(cfg):
    """(roster, now) to display instead of the real thing, or None."""
    ov = get_override()
    if not ov:
        return None
    try:
        return build(ov["scenario"], getattr(cfg, "base", "LGW") or "LGW")
    except Exception:
        clear_override()
        return None
