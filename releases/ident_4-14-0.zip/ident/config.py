"""Configuration, roster persistence, and provider factories.

Settings live in a JSON file in the data directory so the web UI can update
them at runtime. The roster is cached as JSON too, so the wall survives a
reboot without a network round-trip.
"""
from __future__ import annotations

import json
import os
from contextlib import contextmanager
from dataclasses import asdict, dataclass, field

from .models import Roster, roster_from_dict

def _data_dir() -> str:
    """Where config/roster/logos live.

    Honours $IDENT_DATA, else ~/.ident. If ~/.ident doesn't exist yet but an
    older ~/.flightwall does, adopt the old directory so an upgraded install
    keeps its roster, logos and settings instead of starting empty.
    """
    env = os.environ.get("IDENT_DATA")
    if env:
        return env
    new = os.path.expanduser("~/.ident")
    old = os.path.expanduser("~/.flightwall")
    if not os.path.isdir(new) and os.path.isdir(old):
        try:
            os.rename(old, new)          # same filesystem: instant, keeps everything
        except Exception:
            return old                   # couldn't move; keep using the old one
    return new


import threading

_CONFIG_LOCK = threading.RLock()

DATA_DIR = _data_dir()
CONFIG_PATH = os.path.join(DATA_DIR, "config.json")
ROSTER_PATH = os.path.join(DATA_DIR, "roster.json")


@dataclass
class Config:
    # Airline / identity
    airline_iata: str = "U2"          # easyJet (from the sample roster)
    airline_icao: str = "EZY"
    display_prefix: str = "EZY"       # what the wall shows before the flight no.
    base: str = "LGW"

    # Roster source
    ical_url: str = ""
    ical_refresh_minutes: int = 30    # auto-refresh the iCal feed every N minutes (0 = off)

    # Device identity (useful when a pilot runs more than one display)
    device_name: str = "Ident"
    setup_complete: bool = False      # False on a fresh install -> show the setup wizard
    hotspot_after_seconds: int = 120  # offline this long -> raise the "Ident-Setup" hotspot (0 = never)

    # Updates (the device pulls; nothing reaches in from outside)
    update_repo: str = "captaincomplex/ident"
    update_check_hours: int = 24      # 0 disables the check entirely
    auto_update: bool = True          # install new versions without being asked
    auto_update_min_age_hours: int = 72   # ...but only once they've been out this long.
                                      # 0 = take them the moment they're published
                                      # (the developer page can set that)

    # Web panel login (blank password = no login required)
    auth_user: str = "pilot"
    auth_password_hash: str = ""      # set via the panel or --set-password
    auth_epoch: int = 0               # bumped on password change; invalidates old sessions

    # Home-time chain (minutes)
    debrief_minutes: int = 30
    walk_minutes: int = 8             # "walk to car park" slider
    commute_minutes: int = 45         # manual slider

    # Commuters: the journey at the ends of a block is often nothing like the
    # one in the middle of it — 10 minutes from a crashpad on day three, but a
    # two-hour flight home after the last sector.
    commute_split: bool = False       # use the first/last values below
    commute_first_minutes: int = 45   # home -> base, before the first duty of a block
    commute_last_minutes: int = 45    # base -> home, after the last duty of a block

    # Wake-up time
    show_wake: bool = True
    wake_lead_min: int = 90           # awake this long before report
    wake_add_commute: bool = False    # ...plus that day's travel to report

    # Locations for the optional airport-to-base drive lookup used by manually
    # added positioning flights. The live *commute* estimate was removed: it
    # called the Routes API on every 30-second tick while airborne — around a
    # thousand paid calls a day — and blocked the render loop for up to ten
    # seconds each time, to refine a number the owner had already typed in.
    home_lat: float | None = None
    home_lng: float | None = None
    base_lat: float | None = None     # airport / crew car park
    base_lng: float | None = None
    google_maps_api_key: str = ""
    use_maps_commute: bool = False    # ask Maps for a live drive time home
    maps_refresh_minutes: int = 15    # ...and at most this often, during a duty

    # Display
    tz_mode: str = "base"             # utc | base | station
    rows: int = 32
    cols: int = 64
    chain: int = 2
    brightness: int = 60
    hardware_mapping: str = "adafruit-hat"
    renderer: str = "simulator"       # simulator | matrix | vestaboard | epaper
    layout: str = "full"              # full (128x32) | compact (64x32)
    epaper_style: str = "board_solari"  # see render/epaper.py STYLE_LABELS
    epaper_width: int = 600
    epaper_height: int = 448
    epaper_saturation: float = 0.6
    epaper_panel: str = "auto"        # auto | impression_5_7 | impression_4 | impression_7_3 | impression_13_3
    epaper_palette: str = "auto"      # auto | acep7 | spectra6

    # Roster privacy. Every code in duty_codes.DISCREET is hidden and shown as
    # an ordinary day off unless it is listed here. Empty = hide them all, which
    # is the default and the safe direction to be wrong in.
    show_private_codes: list = field(default_factory=list)

    # A photograph on days off, instead of the chosen style
    dayoff_image: str = ""            # filename under DATA_DIR/images
    dayoff_band: bool = True          # next duty across the foot of the picture

    # Scan-to-track QR
    qr_corner: bool = False           # small QR in the corner of every style
    qr_corner_pos: str = "br"         # tl | tr | bl | br
    qr_seconds: int = 20              # how long the full-screen QR stays up
    vestaboard_rw_key: str = ""       # Vestaboard Read/Write API key
    vestaboard_local_ip: str = ""     # optional: local-API IP (faster, offline)

    # Tracking
    tracker: str = "aerodatabox"      # aerodatabox | fr24 | none
    aerodatabox_key: str = ""
    fr24_api_token: str = ""          # Flightradar24 API token (separate product)
    fr24_use_sandbox: bool = False    # test against FR24's free static sandbox
    poll_seconds: int = 180           # fastest live-tracking poll, used on the
                                      # run-in; see tracking.base.poll_interval

    report_lead_min: int = 60         # estimated report lead before STD (typical)
    report_lead_early_min: int = 75   # estimated report lead for early flights
    early_flight_before_hour: int = 7 # STD local-base hour below which a flight is "early"
    personal_report_min: int = 90     # report lead for manually-added personal flights
    duty_gap_hours: float = 5.0       # iCal: gap that splits duties

    def save(self) -> None:
        _write_json(CONFIG_PATH, asdict(self))

    @classmethod
    def update(cls, **fields) -> "Config":
        """Load, change and save as one operation.

        Every route used to do load-modify-save by hand. Waitress runs eight
        threads and the daemon is a ninth, so two settings saved at the same
        moment silently discarded one of them — the owner moves a slider, it
        springs back, and nothing says why.
        """
        with _CONFIG_LOCK:
            cfg = cls.load()
            for k, v in fields.items():
                if k in cls.__annotations__:
                    setattr(cfg, k, v)
            cfg.save()
            return cfg

    @classmethod
    def load(cls) -> "Config":
        if os.path.exists(CONFIG_PATH):
            try:
                with open(CONFIG_PATH) as f:
                    data = json.load(f)
            except (ValueError, OSError) as e:
                # A corrupt config must not stop the device booting: the web
                # panel runs in the daemon's process, so a crash here takes
                # away the only means of fixing it.
                print(f"[ident] config unreadable ({e}); falling back to defaults")
                return cls()
            known = {k: v for k, v in data.items() if k in cls.__annotations__}
            if "setup_complete" not in data:
                # Config written before the setup wizard existed: this is an
                # already-configured install, so don't send it through setup.
                known["setup_complete"] = True
            return cls(**known)
        cfg = cls()
        cfg.save()
        return cfg


def _write_json(path: str, data) -> None:
    """Write JSON so nothing can ever read a half-written file.

    ``open(path, "w")`` truncates to zero and then dribbles the content out
    over several writes. The daemon reloads the roster every tick while the
    web panel writes it, so a reader really does catch it empty — measured at
    72% of reads under load. Worse, a power cut mid-write leaves the file
    truncated permanently, and a daemon that dies on startup takes the web
    panel with it, leaving no way back in short of an SD card reader.

    Write to a temp file alongside, fsync it, then rename. On POSIX the
    rename is atomic: a reader sees the old file or the new one, never a
    fragment. ``devtools.py`` has always done it this way.
    """
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w") as f:
        json.dump(data, f, indent=2)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


@contextmanager
def config_transaction():
    """Hold the lock across a load-modify-save, so two writers can't lose each
    other's changes. Use as::

        with config_transaction() as cfg:
            cfg.base = "LGW"
            cfg.save()
    """
    with _CONFIG_LOCK:
        yield Config.load()


def save_roster(roster: Roster) -> None:
    _write_json(ROSTER_PATH, roster.to_dict())


def load_roster() -> Roster:
    if os.path.exists(ROSTER_PATH):
        try:
            with open(ROSTER_PATH) as f:
                return roster_from_dict(json.load(f))
        except (ValueError, OSError, KeyError) as e:
            print(f"[ident] roster unreadable ({e}); showing NO ROSTER")
            return Roster()
    return Roster()


def refresh_from_ical(cfg: "Config" = None):
    """Fetch the configured iCal feed, parse and store it.

    Returns the number of duties stored, or None if no iCal URL is set.
    Raises on network/parse errors so callers can report them.
    """
    import requests
    from .parsers.ical_parser import parse_ical
    cfg = cfg or Config.load()
    if not cfg.ical_url:
        return None
    MAX_FEED_BYTES = 8 * 1024 * 1024        # a year of duties is well under 1MB
    resp = requests.get(cfg.ical_url, timeout=20, stream=True)
    resp.raise_for_status()
    body = b""
    for chunk in resp.iter_content(64 * 1024):
        body += chunk
        if len(body) > MAX_FEED_BYTES:
            raise ValueError("calendar feed is unreasonably large; refusing it")
    roster = parse_ical(body, base_iata=cfg.base,
                        duty_gap_hours=cfg.duty_gap_hours,
                        report_lead_min=cfg.report_lead_min,
                        debrief_minutes=cfg.debrief_minutes,
                        show_codes=cfg.show_private_codes)
    if not roster.base:
        roster.base = cfg.base
    save_roster(normalize_reports(roster, cfg))
    return len(roster.duties)


_TRANSFER_CACHE: dict = {}


def transfer_minutes_for(cfg: "Config", vm) -> int:
    """Drive minutes from a personal flight's arrival airport to base (cached)."""
    duty = getattr(vm, "duty", None)
    if not (duty and getattr(duty, "personal", False) and duty.sectors):
        return 0
    arr = duty.sectors[-1].arr; base = cfg.base
    if not arr or arr == base or not cfg.google_maps_api_key:
        return 0
    key = (arr, base)
    if key not in _TRANSFER_CACHE:
        from .maps import airport_drive_minutes
        _TRANSFER_CACHE[key] = airport_drive_minutes(cfg.google_maps_api_key, arr, base) or 0
    return _TRANSFER_CACHE[key]


def normalize_reports(roster: Roster, cfg: "Config") -> Roster:
    """Fill in report time only where the calendar didn't give one.

    Calendar-provided report times are left exactly as-is. Estimated ones default
    to ``report_lead_min`` (60) before STD, or ``report_lead_early_min`` (75) for
    early flights (STD local-base hour < ``early_flight_before_hour``).
    """
    import datetime as dt
    from .models import DutyType
    from .timezones import for_display
    base = roster.base or cfg.base
    for d in roster.duties:
        if d.duty_type != DutyType.FLY or not d.sectors or d.personal:
            continue
        if d.report is not None and not d.report_estimated:
            continue                              # trust the calendar exactly
        std = d.sectors[0].std
        try:
            hour = for_display(std, "base", base).hour
        except Exception:
            hour = std.hour
        lead = cfg.report_lead_early_min if hour < cfg.early_flight_before_hour \
            else cfg.report_lead_min
        d.report = std - dt.timedelta(minutes=lead)
        d.report_estimated = True
    return roster


def add_personal_flight(cfg: "Config", flight_no: str, date_iso: str,
                        report_minutes: int | None = None) -> tuple[bool, str]:
    """Look a flight up by number+date and add it as a personal duty.

    Report defaults to ``personal_report_min`` (90) before departure.
    Returns (ok, message).
    """
    import datetime as dt
    import re
    from .models import Sector, Duty, DutyType

    raw = (flight_no or "").strip().upper().replace(" ", "")
    if not raw:
        return False, "Enter a flight number, e.g. U28243 or BA432."
    m = re.match(r"^([A-Z0-9]{2,3}?)(\d{1,4}[A-Z]?)$", raw)
    airline = m.group(1) if m else raw[:2]
    number = m.group(2) if m else raw[2:]
    try:
        the_date = dt.date.fromisoformat(date_iso)
    except Exception:
        return False, "Enter the date as YYYY-MM-DD."

    tracker = build_tracker(cfg)
    if not hasattr(tracker, "lookup_flight"):
        return False, "The current tracker can't look up flights. Switch to AeroDataBox in Advanced."
    info = tracker.lookup_flight(raw, date_iso)
    if not info:
        return False, (f"Couldn't find {raw} on {date_iso}. Check the number/date, and "
                       "that your AeroDataBox key is set in Advanced.")

    sector = Sector(flight_no=number, dep=info["dep"], arr=info["arr"],
                    std=info["std"], sta=info["sta"], aircraft_type=info.get("aircraft"))
    lead = report_minutes if report_minutes is not None else cfg.personal_report_min
    report = info["std"] - dt.timedelta(minutes=lead)
    duty = Duty(date=the_date, duty_type=DutyType.FLY, raw_code="PERSONAL",
                report=report, duty_end=info["sta"], sectors=[sector],
                personal=True, airline=airline)

    roster = load_roster()
    if not roster.base:
        roster.base = cfg.base
    roster.duties = [d for d in roster.duties
                     if not (d.personal and d.date == the_date and d.sectors
                             and d.sectors[0].flight_no == number)]
    roster.duties.append(duty)
    save_roster(roster)
    return True, (f"Added {airline}{number}  {info['dep']}\u2192{info['arr']} on {date_iso} "
                  f"(report {report.strftime('%H:%MZ')}).")


def build_tracker(cfg: Config):
    if cfg.tracker == "aerodatabox":
        from .tracking.aerodatabox import AeroDataBoxTracker
        return AeroDataBoxTracker(cfg.aerodatabox_key)
    if cfg.tracker == "fr24":
        from .tracking.flightradar24 import FlightRadar24Tracker
        return FlightRadar24Tracker(cfg.fr24_api_token, use_sandbox=cfg.fr24_use_sandbox)
    from .tracking.base import NullTracker
    return NullTracker()


def epaper_geometry(cfg: "Config") -> tuple[int, int, str]:
    """The panel's width, height and palette, resolved in one place.

    On a real device InkyRenderer asks the hardware and writes what it found
    back here (see build_renderer below), so config is a record of what is
    actually on the wall rather than a guess. Everything that draws without the
    panel — the web preview, the style thumbnails, /dev — must come through
    here, or it draws a different size and a different palette from the wall.

    ``epaper_panel`` stays as the manual override for when there is no panel to
    ask: previewing another size on a laptop, or hardware inky.auto() cannot
    identify.
    """
    from .render.epaper import PANELS, panel_name
    w, h = cfg.epaper_width, cfg.epaper_height
    if cfg.epaper_panel in PANELS:
        w, h, _pal = PANELS[cfg.epaper_panel]
    pal = cfg.epaper_palette
    if pal == "auto":
        known = panel_name(w, h)
        pal = PANELS[known][2] if known else "acep7"
    return w, h, pal


def adopt_attached_panel() -> str:
    """If a panel is plugged in and no output has been chosen yet, choose it.

    A buyer who clips an Inky onto the header and powers up should get a
    working wall, not a blank one and a settings page they have not been told
    about. This only ever fires while ``renderer`` is still the "simulator"
    default, so a deliberate choice of matrix or vestaboard is never touched.
    Returns a short note for the log, or "".
    """
    from .render.epaper import probe_panel, panel_name
    with _CONFIG_LOCK:
        cfg = Config.load()
        if cfg.renderer != "simulator":
            return ""
    found = probe_panel()
    if not found:
        return ""
    w, h, pal = found
    with _CONFIG_LOCK:
        cfg = Config.load()
        if cfg.renderer != "simulator":       # changed under us
            return ""
        cfg.renderer = "epaper"
        cfg.epaper_width, cfg.epaper_height = w, h
        known = panel_name(w, h)
        if known:
            cfg.epaper_panel = known
        cfg.save()
    return f"found a {known or 'unrecognised'} panel ({w}x{h}, {pal}) — output set to e-paper"


def build_renderer(cfg: Config):
    if cfg.renderer == "matrix":
        from .render.matrix import MatrixRenderer
        return MatrixRenderer(rows=cfg.rows, cols=cfg.cols, chain=cfg.chain,
                              brightness=cfg.brightness,
                              hardware_mapping=cfg.hardware_mapping)
    if cfg.renderer == "vestaboard":
        from .render.vestaboard import VestaboardRenderer
        return VestaboardRenderer(rw_key=cfg.vestaboard_rw_key,
                                  local_ip=cfg.vestaboard_local_ip)
    if cfg.renderer == "epaper":
        from .render.epaper import InkyRenderer, STYLE_LABELS, panel_name
        def _persist(style):
            with config_transaction() as c:
                c.epaper_style = style; c.save()
        def _persist_geometry(w, h, pal):
            """Record what the panel turned out to be, so every preview matches
            it. Geometry only: epaper_palette is left on "auto" so the hardware
            stays the authority if the panel is ever swapped."""
            with config_transaction() as c:
                if (c.epaper_width, c.epaper_height) == (w, h) and \
                   (c.epaper_panel == panel_name(w, h) or not panel_name(w, h)):
                    return
                c.epaper_width, c.epaper_height = w, h
                known = panel_name(w, h)
                if known:
                    c.epaper_panel = known
                c.save()
            print(f"[ident] recorded panel {panel_name(w, h) or 'unknown'} "
                  f"{w}x{h} ({pal}) in config")
        w, h, _pal = epaper_geometry(cfg)
        return InkyRenderer(style=cfg.epaper_style, width=w, height=h,
                            saturation=cfg.epaper_saturation,
                            palette=cfg.epaper_palette,   # "auto" -> ask the panel
                            styles=[k for k, _ in STYLE_LABELS], on_style_change=_persist,
                            qr_corner=cfg.qr_corner, qr_corner_pos=cfg.qr_corner_pos,
                            qr_seconds=cfg.qr_seconds,
                            on_geometry=_persist_geometry)
    from .render.simulator import ConsoleSimulator
    return ConsoleSimulator()


IMAGE_DIR = os.path.join(DATA_DIR, "images")


def dayoff_image_path(cfg: "Config") -> str:
    """Absolute path to the day-off picture, or "" if none is set/usable."""
    name = (getattr(cfg, "dayoff_image", "") or "").strip()
    if not name or os.sep in name or name.startswith("."):
        return ""                       # never let a config value escape the dir
    p = os.path.join(IMAGE_DIR, name)
    return p if os.path.isfile(p) else ""
