"""Live flight tracking provider interface.

Providers translate a roster sector into a ``FlightStatus`` (actual off/on
times, ETA, position, progress). Two implementations are included:

    * AeroDataBox   - query by flight number, returns ETA + actual times (best fit)
    * Flightradar24 - live position by flight number; needs a paid token

Tracking is only polled while the state engine says you are airborne, and the
interval widens the further you are from landing - see ``poll_interval``.
"""
from __future__ import annotations

import datetime as dt
from typing import Optional, Protocol

from ..models import FlightStatus, Roster, Sector


class FlightTracker(Protocol):
    def get_status(self, sector: Sector, airline_iata: str,
                   airline_icao: str) -> Optional[FlightStatus]:
        ...


class NullTracker:
    """Used when no provider is configured; the wall falls back to schedule."""
    def get_status(self, sector, airline_iata, airline_icao):
        return None


def update_sector(sector, tracker: FlightTracker, airline_iata: str,
                  airline_icao: str, now: dt.datetime):
    """Refresh live data for one specific sector.

    Prefer this over ``update_active_sector``. That function searches the
    roster itself and returns the *first* sector whose window contains now —
    and since a window runs to arrival + 2 hours, on a four-sector day the
    first sector's window still covers the second sector's whole flight. The
    result was that the tracker fetched status for a sector that landed 90
    minutes ago, every sector after the first got no live data at all, and the
    API credits were spent anyway. The state engine already knows which sector
    is airborne; ask it, don't guess.
    """
    if sector is None:
        return None
    status = tracker.get_status(sector, airline_iata, airline_icao)
    if status:
        status.fetched_at = now
        sector.live = status
        return sector
    return None


def update_active_sector(roster: Roster, tracker: FlightTracker,
                         airline_iata: str, airline_icao: str,
                         now: dt.datetime) -> Optional[Sector]:
    """Find the sector that should be airborne now and refresh its live data."""
    for duty in roster.duties:
        for s in duty.sectors:
            window_start = (s.live.off_block if s.live and s.live.off_block else s.std)
            window_end = s.sta + dt.timedelta(hours=2)   # generous tail for delays
            if window_start - dt.timedelta(minutes=20) <= now <= window_end:
                status = tracker.get_status(s, airline_iata, airline_icao)
                if status:
                    status.fetched_at = now
                    s.live = status
                    return s
    return None


def poll_interval(base_seconds: int, eta: Optional[dt.datetime],
                  now: dt.datetime) -> int:
    """Seconds to wait before asking the tracker again.

    Requests are spent where they change the answer. An hour out, the landing
    estimate barely moves and asking every three minutes buys nothing; in the
    last twenty minutes it is the number the household is actually reading, so
    it is worth the full rate.

    ``base_seconds`` is that full rate, used on the run-in and whenever the
    aeroplane is running late - a sector past its ETA is exactly when people
    are watching. Further out the interval doubles, then doubles again. Over a
    two-hour sector that is roughly 18 requests instead of 40, without giving
    up any accuracy where it is read.
    """
    base = max(30, int(base_seconds or 180))
    if eta is None:
        return base * 4
    minutes_left = (eta - now).total_seconds() / 60.0
    if minutes_left <= 20:
        return base
    if minutes_left <= 60:
        return base * 2
    return base * 4


def great_circle_progress(lat: float, lon: float, dep: tuple, arr: tuple) -> float:
    """Rough 0..100 progress from current position between dep and arr coords."""
    import math

    def hav(a, b):
        la1, lo1, la2, lo2 = map(math.radians, [a[0], a[1], b[0], b[1]])
        d = (math.sin((la2 - la1) / 2) ** 2
             + math.cos(la1) * math.cos(la2) * math.sin((lo2 - lo1) / 2) ** 2)
        return 2 * math.asin(min(1.0, math.sqrt(d)))

    total = hav(dep, arr)
    if total == 0:
        return 0.0
    done = hav(dep, (lat, lon))
    return max(0.0, min(100.0, 100.0 * done / total))
