# Ident

> **New here, or picking this up after a break? Read [HANDOVER.md](HANDOVER.md) first** —
> where everything lives, how to publish, and what to do next.

A wall-mounted flight-duty board for the Raspberry Pi Zero. It logs into the
pilot's roster and auto-refreshes, showing the current and next duty — sectors,
report time, and first departure — alongside live route maps drawn on a bundled
coastline (rendered on-device, so the Pi needs no heavy geo libraries at runtime).
Physical buttons switch between views (e.g. a "next duty" card).

**Status:** In active development
**Stack:** Raspberry Pi Zero · Python

Part of the [xpdr.aero](https://github.com/captaincomplex/captaincomplex.github.io) projects site.

---

## Overview

A Raspberry Pi + LED-matrix wall that shows **your** roster, not whatever plane
happens to be overhead. Between duties it shows your next flight and report
time; during a duty it tracks the sector you're on, glances at the return
sector, and gives you a live **estimated time home** alongside the landing ETA.

Built around an easyJet LGW roster exported from **eCrew**, but the airline,
base and timezone handling are all configurable.

![in-flight preview](docs/preview_inflight.png)

---

## What it does

- **Reads your roster** two ways:
  - **iCal feed** (primary) — eCrew exports to a calendar; point the wall at the
    `.ics` URL and it pulls duties automatically.
  - **Manual upload** (fallback) — drop a `.ics` file onto the web page when a
    feed isn't available. Reading the eCrew *Personal Crew Schedule Report*
    **PDF** is also supported, as an optional install: it needs pdfplumber,
    which is about 15MB of dependencies and isn't included by default
    (`pip install -r requirements-pdf.txt`).
- **Knows what to show**, by state: day off, standby, next duty (with report
  time), reported, in-flight, turnaround, heading home.
- **Tracks the live flight** while airborne (actual times + ETA), so the wall
  and the home estimate follow reality, not just the schedule.
- **Estimates your time home**: `on-chocks → +30 min debrief → +walk-to-car →
  +commute → home`. Commute is a slider you set once, and optionally a **live
  drive time from Google Maps**, with traffic (*Advanced → Live drive time
  home*, off by default). The first version of that asked on every render tick —
  about a thousand paid calls a day, blocking the render loop for up to ten
  seconds each, to move the number by a minute or two — so it was removed in
  v4.13.0 and brought back in v4.14.0 under three rules: only while a home time
  is on the wall, at most every `maps_refresh_minutes`, and a failure keeps the
  slider. That is a dozen or so calls on a duty day and none on a day off.
- **Timezones**: stores everything in UTC; shows UTC, Local Base, or Local
  Station at the flick of a toggle.
- **Tells you when to wake up**: report minus however long your morning takes,
  optionally plus that day's travel to report.
- **Handles commuting**: separate journey times for the first and last day of a
  block, so a two-hour flight home isn't counted on the days you're in a hotel.
  Positioning flights can be added by flight number.
- **Scan-to-track**: a QR code that opens the live flight — full-screen on a
  button, or small in the corner of any style.
- **A picture on days off**, if you'd rather look at that than an empty board,
  with the next duty optionally across the foot of it.
- **Discreet about private codes** — see below.
- A **web control panel** for uploads, sliders, the timezone toggle, and a live
  preview of the wall — including a *time-travel* field so you can preview what
  it'll show when you land.

## Privacy where it matters

Some roster codes say more than you may want a kitchen wall to say. Eighteen of
them — compassionate leave (`COMP`, `CMPU`), sickness (`SICK`, `MED`, `LOL`),
employment (`RESN`, `TERM`, `SUSP`, `DISC`, `GRV`), family (`MAT`, `PAT`,
`PARL`), and the ambiguous ones where a routine day and a bad day look identical
(`MEET`, `INT`, `SOC`, `UNPD`) — are **hidden by default** and shown as an
ordinary day off.

You choose. The setup wizard lists every one with a plain explanation of why it
might matter, and you tick any you'd rather see; the same list is in settings.
Nothing is revealed unless you ask for it, and the default is to hide.

This is deliberate, and it goes further than hiding them at render time: those
codes are **discarded when the roster is parsed**, so the original never reaches
the device's storage at all. A code that isn't stored can't leak later through a
display style added in a future version, a diagnostics export, or a screenshot
sent to support.

The board hangs somewhere the whole household — and every visitor — can read it.
Whether to explain a particular day off should be your decision, made in your own
time, not something a wall announces on your behalf. See `ident/duty_codes.py` to
add codes for your own airline.

Because hiding happens at parse time, revealing a code only affects rosters read
afterwards — so saving the setting re-reads your feed. A roster you uploaded as a
PDF would need uploading again.

## Developer tools

There's a hidden page at **`/dev`** — reachable by clicking the version number in
the footer of the control panel, and behind the same login as everything else.
It's aimed at anyone tinkering with layouts or adding support for a new airline.

**Preview any duty state.** Sixteen scenarios — airborne, turnaround, delayed
return, heading home, four-sector day, ADTY and ESBY standby, day off, WFTU,
annual leave, training, positioning flight, no roster, and the countdowns either
side of report. Pick one and it renders exactly as the panel would draw it, with
the fields it produced listed underneath.

**Send it to the real panel.** "Send to the panel" makes the display behave as
though that duty were happening now, so you can judge how ADTY actually looks on
e-paper without waiting to be rostered one. It reverts by itself — you choose 5
to 60 minutes, and there's a hard ceiling — so a forgotten simulation can't leave
the wall showing a duty you don't have. Live flight tracking pauses while it's
on, so nothing goes looking up an invented flight number.

**Render every style.** Draws all fourteen styles for the chosen state as a
contact sheet. The quickest way to spot a layout that breaks on, say, a
four-sector day or a very long destination list.

**Classify a calendar event.** Paste the `SUMMARY`, `LOCATION` and `DESCRIPTION`
of one event from an airline's feed and see how the parser reads it. Sectors that
are really duty envelopes — the same airport at both ends, or no flight number —
are flagged in red. That is the exact shape that once put `EZY---- LGW-LGW` on a
wall for a whole trip, and it's now visible in a single paste.

**Parse a whole `.ics`.** Paste a complete feed and get every duty it produces in
a table, with the suspect ones flagged. Nothing is saved; it only reads. This is
the loop for turning a sample roster from another airline into working support.

**Diagnostics.** Links to the redacted support report, the raw config and the
current state as JSON.

## Display options

The flight number prefix shown on the wall is configurable (defaults to the
ICAO **EZY**; set it to anything under *Advanced → shown on wall as*).

Four outputs, selectable in the panel:

- **E-paper (Inky Impression)** — **the reference build**, and what the product
  is sold as. 4.0″ (600×400), 7.3″ (800×480) and 13.3″ (1600×1200) Spectra 6
  panels, plus the discontinued 5.7″ (600×448, ACeP 7-colour). The panel is
  identified over I2C at startup and its geometry recorded in config, so the
  control panel's preview always matches the wall. Fourteen styles; the month
  calendar needs 700×420 or more and is simply not offered below that.
- **Full LED (128×32)** — the original build, mains-only. While airborne the wall shows a
  full-width **route map**: a great-circle arc from departure to arrival with a
  moving aircraft marker, the landing time and your home time in the corners.
  The text states (next duty, turnaround, heading home) right-justify the home
  value so the width isn't wasted.
- **Compact LED (64×32)** — half the panel, lower cost. Everything still fits,
  but a 64-px row only holds ~12 characters, so the in-flight view stacks the
  route, a straight progress track, the landing time and the home time; long
  routes scroll. Fewer fields are visible at once than on the full board.
- **Vestaboard (split-flap)** — see below.

## Vestaboard / split-flap feasibility

A Vestaboard is a 6×22 grid of mechanical character "Bits". It can show
letters, digits, basic punctuation and seven colour chips — **no free-form
graphics** — and every change physically flips, so updates are slow and
rate-limited. That makes it a lovely fit for the **text** states (next duty,
report time, home time) and a weak fit for a smooth live map; the route is
reduced to a coarse chip-based progress bar, e.g.

```
+----------------------+
|IN FLIGHT      EZY8243|
|                      |
|LGW ======■------- SKG|
|                      |
|LAND 09:48 HOME  15:57|
|                      |
+----------------------+
```

A `VestaboardRenderer` is included (`ident/render/vestaboard.py`). It
encodes the screen into the 6×22 character-code array and posts it via either
the **Read/Write API** (cloud key from the app) or the **Local API** (board IP +
key, faster and offline). It only pushes when the board content actually changes
and not more than once every ~15 s, to respect the flaps and the API limits.
Set *Output → Vestaboard* and paste your Read/Write key. Note Vestaboard is a
premium product (a few hundred £/$, depending on model) — check current pricing
before committing.

## Hardware (suggested)

| Part | Notes |
|------|-------|
| Raspberry Pi Zero 2 W (or Pi 4) | Pi handles the roster/timezone/state logic far more easily than the ESP32 the original Ident uses |
| Adafruit RGB Matrix Bonnet / HAT | Saves hand-wiring the HUB75 GPIO |
| 2 × 64×32 HUB75 RGB panels (=128×32) | Two chained panels give room for text; a single 64×32 works with more truncation |
| 5 V / 4 A+ PSU | LED panels are hungry; don't power them from the Pi |

The text-heavy layout is why two chained panels are recommended — a single
64×32 is tight for flight number + route + times + home line.

## Software setup

### On any machine (development / simulator)

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
pip install -r requirements-pdf.txt   # optional: read eCrew roster PDFs
python -m ident.main            # simulator + web panel on :8080
```

Open <http://localhost:8080>, drop in your roster PDF, and you'll see the wall
render in the browser. The `simulator` renderer needs no hardware.

### On the Raspberry Pi — e-paper (the reference build)

See **[INSTALL_PI.md](INSTALL_PI.md)** for the full headless walkthrough, or
`docs/guides/IDENT_BEGINNERS_GUIDE.md` for the version written for someone who
has never used a Pi. The short form:

```bash
sudo raspi-config nonint do_spi 0 && sudo raspi-config nonint do_i2c 0 && sudo reboot
sudo apt install -y python3-venv python3-pip unzip fonts-dejavu-core python3-lgpio
python3 -m venv .venv --system-site-packages && source .venv/bin/activate
pip install -r requirements.txt -r requirements-epaper.txt
python -m ident.main
```

There is nothing to edit by hand. On first start Ident probes the header; if a
panel answers, it sets `renderer` to `epaper` and records the geometry, then the
first-run wizard at `http://ident.local:8080` collects everything else.

### On the Raspberry Pi — LED matrix

1. Install deps: `pip install -r requirements.txt`
2. Build hzeller's LED library (the Python binding is **not** on PyPI):
   ```bash
   git clone https://github.com/hzeller/rpi-rgb-led-matrix
   cd rpi-rgb-led-matrix
   make build-python PYTHON=$(which python3)
   sudo make install-python PYTHON=$(which python3)
   ```
3. In the web panel, set **Output → LED matrix** (and rows/cols/chain to match
   your panels), then run with `sudo` (GPIO access):
   ```bash
   sudo python -m ident.main
   ```
4. To start on boot, add a small `systemd` service that runs the same command.

## Live tracking & cost

While you're airborne (and only then), the daemon polls the configured provider
for the active sector every few minutes, merges the live data (position, ETA,
actual off/on) into that sector, and the wall + home estimate update. On the
ground it uses the roster's scheduled times.

- **AeroDataBox** (default, via RapidAPI) — query by flight number, returns a
  predicted ETA and actual times. The most direct fit for the landing time and
  home estimate. Small free tier; moved to credit-based billing in 2026.
- **Flightradar24 API** — excellent **live position** (drives the route-map
  marker), filtered by flight number. Position-centric, so ETA falls back to
  schedule unless the live record carries one. See the note below.
- **None** — schedule only. The wall still works: times come from the roster,
  which is right until the day something is delayed.

Tracking is polled only while airborne, and the interval widens the further
you are from landing — every ~12 minutes in the early cruise, tightening to
the configured rate over the last twenty minutes and whenever a sector is
running late. That is roughly 18 requests over a two-hour sector rather than
40, so free and cheap tiers go a long way. Set the provider and key under
*Advanced*.

### About Flightradar24 (and a Contributor plan)

Two different products share the name:

1. **Flightradar24.com subscription / Contributor plan.** Hosting an ADS-B
   receiver earns the complimentary **Contributor** plan — premium features on
   the website and app. It does **not** include API tokens.
2. **Flightradar24 API** (`fr24api.flightradar24.com`) — a separate, credit-
   billed product with its own tokens, a free **sandbox**, and an *Explorer*
   tier aimed at hobby projects. This is what the `fr24` tracker uses.

So your Contributor status doesn't directly plug into the wall, but if you want
FR24 specifically: create an API token on the FR24 portal, pick *Explorer* (or
test in the sandbox first), and paste it under *Advanced → Flightradar24 API
token*. Because tracking only runs while airborne, credit use is tiny. FR24 is
the best choice for an accurate live **map marker**; pair it with AeroDataBox if
you also want a predicted ETA, or just use AeroDataBox alone for the simplest
ETA + home-time path.

> **Bonus if you feed FR24 yourself:** your receiver runs a local `dump1090`
> feed (JSON at `http://<receiver>/data/aircraft.json`) that's free and real-time
> for aircraft *in range of your antenna* — i.e. your departures out of and
> arrivals back into the base, though not the cruise across Europe. A
> `dump1090` tracker would be a tidy free add-on for the in-range legs; ask if
> you'd like it wired in.

## The iCal feed (AIMS eCrew format — now supported)

The **primary** path is your eCrew calendar feed. The parser
(`ident/parsers/ical_parser.py`) is built for the AIMS eCrew event format,
confirmed from a real event:

```
SUMMARY:     8301 LGW-MXP
DTSTART/END: 05:40 - 08:55          (reporting time -> arrival, not the STD)
LOCATION:    (0555Z-0755Z) LGW      (block time in UTC + departure station)
DESCRIPTION: Reporting time : 0540
             8301  - LGW  (0655) - MXP  (0855)
             * All times in Local Base (LGW)
```

Key point: AIMS pads the first event's start to the **reporting time**, so the
parser reads sector times from the **DESCRIPTION** (Local Base), uses the
`Reporting time` line for the duty report, groups per-sector events into duties
by time gap, and cross-checks against the LOCATION Zulu times. This is covered
by tests against the real event and a sample feed (`tests/fixtures/aims_sample.ics`).

The one remaining unknown is the exact wording AIMS uses for **standby / day
off / training** events — those are matched by keyword (`ESBY`, `PSBE`, `D/O`,
`FTGD`, "standby", "day off", …) and are easy to extend at the top of the parser
once you've seen how yours read. Uploading a `.ics` file by hand covers the
case where the feed itself is unreachable, and the eCrew **PDF** path is there
too if you install it.

## Project layout

```
ident/
  models.py            roster data model (UTC internally)
  timezones.py         IATA -> tz, UTC/base/station conversion
  parsers/
    ecrew_pdf.py       eCrew Schedule Report PDF  (optional install)
    ical_parser.py     iCal feed  (tolerant; tweak to your feed's wording)
  state_engine.py      current state + home-time chain
  tracking/            AeroDataBox / Flightradar24 / null providers
  render/
    presenter.py       ViewModel -> display lines (timezone aware)
    simulator.py       console + PNG preview (no hardware)
    matrix.py          HUB75 output via rpi-rgb-led-matrix
  maps.py              airport-to-base drive time for positioning flights
  web/                 Flask control panel
  main.py              daemon loop
tests/                 parsing + state-engine + home-math tests
```

## Tests

```bash
python -m pytest tests/ -q
```

Roster-PDF tests need a real roster, which isn't in the repo; point
`IDENT_TEST_PDF` at a copy to run them, otherwise they skip.

## What's verified vs. what needs your kit

- **Verified** against real data: the eCrew **PDF** parsing, the **AIMS iCal**
  event format (sector times, reporting time, duty grouping, standby/day-off),
  the state machine, timezone conversion, and the home-time maths.
- **Needs your environment** (network / hardware, so untested here): the live
  tracking providers, Google Maps, the physical LED output, the Vestaboard API,
  and the exact wording of standby/day-off events in *your* feed. These are
  written and guarded, but expect a little tuning on first run.
