"""Decide what the wall should show right now, and when you'll get home.

Home-time chain (your spec):

    on-chocks (last sector arrival)
      + 30 min debrief
      + walk-to-car-park   (slider)
      + commute            (slider, or live Google Maps drive time)
      = home

While airborne we prefer live data (actual off-blocks / ETA) over the roster's
scheduled times, so the estimate sharpens as the duty progresses.
"""
from __future__ import annotations

import datetime as dt
from dataclasses import dataclass, field
from typing import Optional

from .models import Duty, DutyState, DutyType, Roster, Sector


@dataclass
class HomeEstimate:
    on_chocks: Optional[dt.datetime] = None
    debrief_end: Optional[dt.datetime] = None
    commute_start: Optional[dt.datetime] = None   # after walk to car park
    home_eta: Optional[dt.datetime] = None
    is_live: bool = False                          # built on live ETA vs schedule
    commute_used: int = 0                          # minutes actually applied
    end_of_block: bool = False                     # ...and whether that was the long one


def _working(duty: Optional[Duty]) -> bool:
    """A duty that puts you at work, for the purpose of grouping days into blocks."""
    return bool(duty) and duty.duty_type in (DutyType.FLY, DutyType.STANDBY,
                                             DutyType.TRAINING)


def _worked_on(roster: Roster, day: dt.date) -> bool:
    return any(_working(d) for d in roster.duties if d.date == day)


def block_position(roster: Roster, duty: Duty) -> tuple[bool, bool]:
    """(first of a block, last of a block).

    A block is a run of consecutive days at work. Day-based rather than
    duty-based because that is how crew talk about it — and because a duty that
    lands after midnight shouldn't start a new block on its own.
    """
    if not _working(duty):
        return (False, False)
    day = duty.date
    same_day = sorted((d for d in roster.duties
                       if d.date == day and _working(d)),
                      key=lambda d: (d.report or d.sectors[0].std if d.sectors
                                     else dt.datetime.min.replace(tzinfo=dt.timezone.utc)))
    first_today = (not same_day) or same_day[0] is duty
    last_today = (not same_day) or same_day[-1] is duty
    first = first_today and not _worked_on(roster, day - dt.timedelta(days=1))
    last = last_today and not _worked_on(roster, day + dt.timedelta(days=1))
    return (first, last)


def commute_for(roster: Roster, duty: Duty, cfg_like) -> tuple[int, int]:
    """(minutes travelling *to* report, minutes travelling home afterwards).

    ``cfg_like`` is anything with the commute_* attributes — the Config, or a
    stand-in in tests.
    """
    normal = int(getattr(cfg_like, "commute_minutes", 0) or 0)
    if not getattr(cfg_like, "commute_split", False):
        return (normal, normal)
    first, last = block_position(roster, duty)
    out = int(getattr(cfg_like, "commute_first_minutes", normal) or 0) if first else normal
    back = int(getattr(cfg_like, "commute_last_minutes", normal) or 0) if last else normal
    return (out, back)


def wake_time(duty: Duty, *, wake_lead_min: int = 90,
              commute_to_report: int = 0,
              add_commute: bool = False) -> Optional[dt.datetime]:
    """When the alarm needs to go off. None when there's no report time."""
    if not duty or not duty.report:
        return None
    lead = max(0, int(wake_lead_min or 0))
    if add_commute:
        lead += max(0, int(commute_to_report or 0))
    return duty.report - dt.timedelta(minutes=lead)


@dataclass
class ViewModel:
    """Everything the renderer needs, timezone-agnostic (UTC datetimes)."""
    state: DutyState
    now: dt.datetime
    base: str = ""
    duty: Optional[Duty] = None
    active_sector: Optional[Sector] = None
    return_sector: Optional[Sector] = None         # other sector(s) same duty
    next_sector: Optional[Sector] = None           # for turnaround
    next_duty: Optional[Duty] = None               # soonest real duty (day-off board)
    home: Optional[HomeEstimate] = None
    roster: Optional[Roster] = None                # for whole-month views
    wake: Optional[dt.datetime] = None             # alarm for the duty being shown
    next_wake: Optional[dt.datetime] = None        # ...and for the next one, on days off
    first_of_block: bool = False
    last_of_block: bool = False
    countdown_to: Optional[dt.datetime] = None      # report / STD to count down to
    countdown_label: str = ""
    messages: list[str] = field(default_factory=list)


def compute_view(roster: Roster, now: dt.datetime, *, debrief_minutes: int = 30,
                 walk_minutes: int = 0, commute_minutes: int = 0,
                 live_commute_minutes: Optional[int] = None,
                 transfer_minutes: int = 0, cfg=None) -> ViewModel:
    if now.tzinfo is None:
        now = now.replace(tzinfo=dt.timezone.utc)
    commute = live_commute_minutes if live_commute_minutes is not None else commute_minutes

    if not roster.duties:
        return ViewModel(state=DutyState.NO_ROSTER, now=now, base=roster.base)

    # Keep a finished duty on screen for the whole journey home. The longest
    # possible tail is used for the lookup, then the duty's own numbers decide
    # the actual home time below.
    _tail = int(debrief_minutes or 0) + int(walk_minutes or 0) + max(
        int(commute or 0),
        int(getattr(cfg, "commute_last_minutes", 0) or 0) if getattr(
            cfg, "commute_split", False) else 0)
    duty = _current_or_next_duty(roster, now, tail_minutes=_tail)
    if duty is None:
        return ViewModel(state=DutyState.NO_ROSTER, now=now, base=roster.base)

    vm = ViewModel(state=DutyState.BETWEEN_DUTIES, now=now, base=roster.base, duty=duty)
    vm.next_duty = _next_real_duty(roster, now)
    vm.roster = roster                      # the month view needs the whole thing

    def _wake_for(d):
        """Alarm for duty *d*, using that day's own travel time."""
        if d is None or cfg is None or not getattr(cfg, "show_wake", True):
            return None
        out, _back = commute_for(roster, d, cfg)
        return wake_time(d, wake_lead_min=getattr(cfg, "wake_lead_min", 90),
                         commute_to_report=out,
                         add_commute=getattr(cfg, "wake_add_commute", False))

    vm.first_of_block, vm.last_of_block = block_position(roster, duty)
    vm.wake = _wake_for(duty)
    vm.next_wake = _wake_for(vm.next_duty)

    # A live drive time is a *home* number; it says nothing about a two-hour
    # flight at the end of a block, so it only overrides the ordinary case.
    if cfg is not None and getattr(cfg, "commute_split", False) \
            and live_commute_minutes is None:
        _out, commute = commute_for(roster, duty, cfg)

    # Non-flying duties.
    if duty.duty_type == DutyType.DAY_OFF:
        vm.state = DutyState.DAY_OFF
        vm.next_duty = _next_real_duty(roster, now)
        return vm
    if duty.duty_type == DutyType.STANDBY:
        if duty.standby_start and duty.standby_start <= now <= (duty.standby_end or now):
            vm.state = DutyState.STANDBY
        else:
            vm.state = DutyState.BETWEEN_DUTIES
            vm.countdown_to = duty.standby_start
            vm.countdown_label = "STBY"
        return vm
    if duty.duty_type in (DutyType.TRAINING, DutyType.OTHER):
        vm.state = DutyState.BETWEEN_DUTIES
        vm.countdown_to = duty.report
        vm.countdown_label = duty.raw_code or "DUTY"
        return vm

    # --- Flying duty ---------------------------------------------------------
    sectors = duty.sectors
    active = _airborne_sector(sectors, now)
    home = _home_estimate(duty, debrief_minutes, walk_minutes, commute,
                          base=roster.base, transfer_minutes=transfer_minutes)
    home.end_of_block = vm.last_of_block
    vm.home = home

    if duty.report and now < duty.report:
        vm.state = DutyState.BETWEEN_DUTIES
        vm.countdown_to = duty.report
        vm.countdown_label = "RPT"
        vm.next_sector = sectors[0]
        vm.return_sector = sectors[-1] if len(sectors) > 1 else None
        return vm

    if active is not None:
        vm.state = DutyState.IN_FLIGHT
        vm.active_sector = active
        others = [s for s in sectors if s is not active and s.std >= active.std]
        vm.return_sector = others[0] if others else None
        vm.countdown_to = active.effective_arrival()
        vm.countdown_label = "LAND"
        return vm

    # Reported but not airborne: either pre-first-departure or a turnaround.
    next_sec = _next_sector(sectors, now)
    if next_sec is None:
        vm.state = DutyState.POST_DUTY
        vm.countdown_to = home.home_eta if home else None
        vm.countdown_label = "HOME"
        return vm

    if next_sec is sectors[0]:
        vm.state = DutyState.PRE_FLIGHT
        vm.countdown_to = next_sec.effective_departure()
        vm.countdown_label = "DEP"
    else:
        vm.state = DutyState.TURNAROUND
        vm.countdown_to = next_sec.effective_departure()
        vm.countdown_label = "DEP"
    vm.next_sector = next_sec
    vm.active_sector = next_sec
    vm.return_sector = sectors[-1] if next_sec is not sectors[-1] else None
    return vm


# --- helpers -----------------------------------------------------------------

def _current_or_next_duty(roster: Roster, now: dt.datetime,
                          tail_minutes: int = 0) -> Optional[Duty]:
    """The duty in progress, else the soonest upcoming, else the most recent today."""
    duties = roster.sorted_duties()
    # A duty holds the screen until the next one starts, so the journey-home
    # tail never eats into the next duty. This matters for commuters: landing
    # at base off a positioning flight isn't "heading home", it's arriving for
    # work, and the next duty should take over.
    starts = [_duty_window(d)[0] for d in duties]
    in_progress = []
    for i, d in enumerate(duties):
        # A positioning flight that lands at base is arriving for work, not
        # going home — so it gets no journey-home tail.
        tail = 0 if (getattr(d, "personal", False) and roster.base
                     and d.sectors and d.sectors[-1].arr == roster.base) else tail_minutes
        s, e = _duty_window(d, tail)
        later = [x for x in starts[i + 1:] if x > _duty_window(d)[1]]
        if later:
            e = min(e, later[0])
        if s <= now <= e:
            in_progress.append(d)
    if in_progress:
        return in_progress[-1]
    upcoming = [d for d in duties if _duty_window(d)[0] > now]
    if upcoming:
        return min(upcoming, key=lambda d: _duty_window(d)[0])
    today = [d for d in duties if d.date == now.date()]
    return today[-1] if today else (duties[-1] if duties else None)


def _next_real_duty(roster: Roster, now: dt.datetime) -> Optional[Duty]:
    """Soonest upcoming duty that isn't a day off (for the day-off board)."""
    upcoming = [d for d in roster.sorted_duties()
                if d.duty_type != DutyType.DAY_OFF and _duty_window(d)[0] > now]
    return min(upcoming, key=lambda d: _duty_window(d)[0]) if upcoming else None


def _duty_window(d: Duty, tail_minutes: int = 0) -> tuple[dt.datetime, dt.datetime]:
    """When this duty owns the screen.

    ``tail_minutes`` extends a flying duty past its end to cover the journey
    home. Without it the board flips away from "heading home" the instant the
    last sector lands — which is the exact moment the people at home start
    caring. It matters more now the journey home can be a two-hour flight.
    """
    midnight = dt.datetime(d.date.year, d.date.month, d.date.day, tzinfo=dt.timezone.utc)
    if d.duty_type == DutyType.STANDBY and d.standby_start:
        return d.standby_start, (d.standby_end or d.standby_start)
    if d.is_flying:
        start = d.report or d.sectors[0].std
        end = d.duty_end or d.sectors[-1].sta
        return start, end + dt.timedelta(minutes=max(0, tail_minutes))
    return midnight, midnight + dt.timedelta(hours=24)


def _real_sector(s: Sector) -> bool:
    """A sector that describes an actual flight rather than a duty envelope."""
    return bool(s.dep and s.arr and s.dep != s.arr
                and (s.flight_no or "").strip(" -–") != "")


def _airborne_sector(sectors: list[Sector], now: dt.datetime) -> Optional[Sector]:
    # Prefer a genuine flight. A malformed feed can hand us a sector covering
    # the whole duty (same airport both ends, no flight number); if one of those
    # ever gets through the parser again it must not out-rank the real thing.
    airborne = [s for s in sectors
                if s.effective_departure() <= now <= s.effective_arrival()]
    for s in airborne:
        if _real_sector(s):
            return s
    for s in airborne:
        return s
    return None


def _next_sector(sectors: list[Sector], now: dt.datetime) -> Optional[Sector]:
    upcoming = [s for s in sectors if s.effective_departure() > now]
    return min(upcoming, key=lambda s: s.effective_departure()) if upcoming else None


def _home_estimate(duty: Duty, debrief_minutes: int, walk_minutes: int,
                   commute_minutes: int, base: str = "", transfer_minutes: int = 0) -> HomeEstimate:
    last = duty.sectors[-1]
    on_chocks = last.effective_arrival()
    is_live = bool(last.live and (last.live.on_block or last.live.eta))
    if getattr(duty, "personal", False) and base and last.arr != base:
        # Non-work flight landing away from base: drive arr->base, then commute home.
        commute_start = on_chocks + dt.timedelta(minutes=transfer_minutes)
        debrief_end = on_chocks
        home_eta = commute_start + dt.timedelta(minutes=commute_minutes)
    else:
        debrief_end = on_chocks + dt.timedelta(minutes=debrief_minutes)
        commute_start = debrief_end + dt.timedelta(minutes=walk_minutes)
        home_eta = commute_start + dt.timedelta(minutes=commute_minutes)
    return HomeEstimate(on_chocks=on_chocks, debrief_end=debrief_end,
                        commute_start=commute_start, home_eta=home_eta,
                        is_live=is_live, commute_used=int(commute_minutes or 0))
