"""Ident daemon.

Each tick it recomputes the current state and renders it. While you're airborne
it polls the live tracker (at most every poll_seconds) and merges actual times /
ETA into the active sector so the wall and the home estimate track reality.

Run on the Pi:
    python -m ident.main              # renders to configured output + web UI
    python -m ident.main --no-web     # headless

The web control panel runs in a background thread on port 8080 by default.
"""
from __future__ import annotations

import argparse
import datetime as dt
import threading
import time

from .config import Config, build_renderer, build_tracker, load_roster
from .maps import drive_minutes
from .render.presenter import present
from .state_engine import DutyState, compute_view
from .tracking.base import update_active_sector


def _start_web(port: int):
    """Serve the control panel.

    Uses waitress - a production WSGI server - rather than Flask's development
    server, which is single-threaded and explicitly not meant to face a network.
    Falls back to Flask's server so an existing install without waitress keeps
    working after an update.
    """
    from .web.app import create_app
    app = create_app()

    def _serve():
        try:
            from waitress import serve
            serve(app, host="0.0.0.0", port=port, threads=8, ident="Ident")
        except ImportError:
            print("[ident] waitress not installed - falling back to the "
                  "development server (run: pip install waitress)")
            app.run(host="0.0.0.0", port=port, debug=False, use_reloader=False)

    threading.Thread(target=_serve, daemon=True).start()


def run(enable_web: bool = True, port: int = 8080, tick_seconds: int = 30):
    cfg = Config.load()
    renderer = build_renderer(cfg)
    tracker = build_tracker(cfg)
    try:
        from . import geo
        threading.Thread(target=geo.prefetch, daemon=True).start()
    except Exception:
        pass
    if enable_web:
        _start_web(port)
        print(f"[ident] control panel on http://0.0.0.0:{port}")

    last_poll = 0.0
    last_ical = 0.0
    last_upd = 0.0
    offline_since = None
    update_info = {}
    maps_commute = None
    from . import __version__
    print(f"[ident] v{__version__} started · output={cfg.renderer} · tracker={cfg.tracker}")
    while True:
        cfg = Config.load()                      # pick up web edits live
        if cfg.ical_url and cfg.ical_refresh_minutes and \
           (time.time() - last_ical >= cfg.ical_refresh_minutes * 60):
            try:
                from .config import refresh_from_ical
                n = refresh_from_ical(cfg)
                if n is not None:
                    print(f"[ident] iCal auto-refresh: {n} duties")
            except Exception as e:
                print(f"[ident] iCal refresh error: {e}")
            last_ical = time.time()
        # No network? Put up our own hotspot so it can be set up from a phone.
        try:
            from . import onboarding as _ob
            if _ob.is_online():
                offline_since = None
                if _ob.ap_active():
                    print("[ident] back online - stopping setup hotspot")
                    _ob.stop_ap()
            elif not _ob.ap_active():
                if offline_since is None:
                    offline_since = time.time()
                elif time.time() - offline_since >= cfg.hotspot_after_seconds > 0:
                    ok, info = _ob.start_ap()
                    print(f"[ident] offline - setup hotspot '{info}'" if ok
                          else f"[ident] could not start hotspot: {info}")
        except Exception as e:
            print(f"[ident] onboarding check failed: {e}")

        if cfg.update_check_hours and (time.time() - last_upd >= cfg.update_check_hours*3600):
            try:
                from .updates import check as _check
                update_info = _check(cfg.update_repo)
                if update_info.get("update_available"):
                    print(f"[ident] update available: {update_info['latest']} "
                          f"(running {update_info['current']})")
            except Exception as e:
                print(f"[ident] update check failed: {e}")
            last_upd = time.time()
        roster = load_roster()
        now = dt.datetime.now(dt.timezone.utc)

        # Developer preview: pretend a chosen duty is happening right now. The
        # override carries its own expiry, so this can't strand the wall.
        _dev = None
        try:
            from .devtools import override_view
            _dev = override_view(cfg)
        except Exception:
            _dev = None
        if _dev:
            roster, now = _dev

        # Provisional view to learn the state cheaply.
        vm = compute_view(roster, now, debrief_minutes=cfg.debrief_minutes,
                          walk_minutes=cfg.walk_minutes,
                          commute_minutes=cfg.commute_minutes, cfg=cfg)

        # Poll live tracking only while airborne, and not too often.
        if vm.state == DutyState.IN_FLIGHT and cfg.tracker != "none" and not _dev:
            if time.time() - last_poll >= cfg.poll_seconds:
                try:
                    update_active_sector(roster, tracker, cfg.airline_iata,
                                         cfg.airline_icao, now)
                except Exception as e:
                    print(f"[ident] tracker error: {e}")
                last_poll = time.time()

        # Optional live commute time, refreshed near end of duty.
        live_commute = None
        if cfg.use_maps_commute and cfg.google_maps_api_key and cfg.home_lat:
            if vm.home and vm.home.commute_start:
                if maps_commute is None or vm.state in (DutyState.IN_FLIGHT,
                                                        DutyState.TURNAROUND):
                    maps_commute = drive_minutes(
                        cfg.google_maps_api_key,
                        (cfg.base_lat, cfg.base_lng), (cfg.home_lat, cfg.home_lng),
                        depart_at=vm.home.commute_start)
            live_commute = maps_commute

        vm = compute_view(roster, now, debrief_minutes=cfg.debrief_minutes,
                          walk_minutes=cfg.walk_minutes,
                          commute_minutes=cfg.commute_minutes,
                          live_commute_minutes=live_commute, cfg=cfg)
        from .config import transfer_minutes_for
        _tr = transfer_minutes_for(cfg, vm)
        if _tr:
            vm = compute_view(roster, now, debrief_minutes=cfg.debrief_minutes,
                              walk_minutes=cfg.walk_minutes,
                              commute_minutes=cfg.commute_minutes,
                              live_commute_minutes=live_commute, transfer_minutes=_tr, cfg=cfg)
        screen = present(vm, tz_mode=cfg.tz_mode, flight_prefix=cfg.display_prefix, iata=cfg.airline_iata, now=now)

        try:
            renderer.show(screen)
        except Exception as e:
            print(f"[ident] render error: {e}")

        time.sleep(tick_seconds)


def main():
    ap = argparse.ArgumentParser(description="Ident daemon")
    ap.add_argument("--no-web", action="store_true", help="disable the web panel")
    ap.add_argument("--port", type=int, default=8080)
    ap.add_argument("--tick", type=int, default=30, help="render interval seconds")
    ap.add_argument("--set-password", action="store_true",
                    help="set (or clear) the web panel login, then exit")
    args = ap.parse_args()
    if args.set_password:
        import getpass
        from .auth import hash_password
        cfg = Config.load()
        user = input(f"Username [{cfg.auth_user or 'pilot'}]: ").strip() or (cfg.auth_user or "pilot")
        pw = getpass.getpass("Password (blank to disable login): ")
        if pw and pw != getpass.getpass("Confirm password: "):
            print("Passwords did not match."); return
        cfg.auth_user = user
        cfg.auth_password_hash = hash_password(pw) if pw else ""
        cfg.save()
        print(f"Login {'enabled for user ' + user if pw else 'disabled'}.")
        return
    try:
        run(enable_web=not args.no_web, port=args.port, tick_seconds=args.tick)
    except KeyboardInterrupt:
        print("\n[ident] stopped")


if __name__ == "__main__":
    main()
