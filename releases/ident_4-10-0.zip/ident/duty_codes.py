"""Duty codes, in one place — including the ones that must never be displayed.

Some roster codes say something the rest of the room has no business reading off
a wall. Compassionate leave is the obvious one: the board is in a kitchen, and a
visitor shouldn't learn that a bereavement is in progress because a four-letter
code appeared on it.

Those codes are mapped to a day off **at parse time**, and the original code is
not kept. That is deliberate — a code that is never stored cannot leak through a
style we add later, a diagnostics export, or a screenshot sent to support. The
duty still shows correctly as a day off, which is what it is.

Both parsers import from here, so adding an airline's codes is one edit.
"""
from __future__ import annotations

import re

from .models import DutyType

# Shown as an ordinary day off, with the real code discarded.
#   COMP  compassionate leave
#   CMPU  compassionate leave, unpaid
#   SOC   subject to operational clearance — a request that may still be refused,
#         and not something to announce before it is settled
DISCREET_CODES = {
    "COMP", "CMPU", "COMPU", "CL", "CPL",
    "SOC", "STOC",
    "PARENTAL", "PAT", "MAT", "PATL", "MATL",
    "SICK", "SIC", "S/L", "SL",
}

DISCREET_PHRASES = (
    "compassionate", "bereavement", "subject to operational clearance",
    "parental leave", "maternity", "paternity", "sick leave",
)

PUBLIC_SUBSTITUTE = "D/O"

OFF_CODES = {"D/O", "DO", "OFF", "WFTU", "AL", "ANNUAL LEAVE", "LVE", "REST"}
STANDBY_CODES = {"PSBE", "ESBY", "LSBY", "ASBY", "HSBY", "STBY", "SBY",
                 "ADTY", "APTD"}
TRAINING_CODES = {"FTGD", "SIM", "GS", "OJT", "LPC", "OPC", "CRM"}

_WORD = re.compile(r"[A-Z][A-Z0-9/]*")


def _tokens(text: str) -> set[str]:
    return set(_WORD.findall((text or "").upper()))


def is_discreet(text: str) -> bool:
    """Does this duty describe something private?

    Matched on whole tokens, not substrings: "COMP" must not be found inside
    "COMPLETED", and "SL" must not match "SLIP".
    """
    low = (text or "").lower()
    if any(p in low for p in DISCREET_PHRASES):
        return True
    return bool(_tokens(text) & DISCREET_CODES)


def public_code(raw: str) -> str:
    """What may be shown. Private codes become an ordinary day off."""
    return PUBLIC_SUBSTITUTE if is_discreet(raw) else (raw or "")


def classify(text: str) -> DutyType | None:
    """Duty type from a code or summary, or None if it isn't recognised."""
    if is_discreet(text):
        return DutyType.DAY_OFF
    toks = _tokens(text)
    if toks & OFF_CODES:
        return DutyType.DAY_OFF
    if toks & STANDBY_CODES:
        return DutyType.STANDBY
    if toks & TRAINING_CODES:
        return DutyType.TRAINING
    return None
