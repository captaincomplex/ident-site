# Installing Ident on a Raspberry Pi (headless, e-paper)

You don't need a monitor, and you don't need to edit any files. The Pi is set up
over your network: you SSH in once to install it, then everything else happens
in a browser on your phone. The e-ink panel is the only display it ever drives.

> **New to the Raspberry Pi?** Use the illustrated walkthrough instead —
> `docs/guides/IDENT_BEGINNERS_GUIDE.md`, which covers what to buy and assumes
> nothing. This page is the short version, for someone who has done it before.

**You need:** the Pi (Zero 2 W / 3A+ / 3 / 4 / 5), an Inky Impression on the
40-pin header (4.0", 7.3" or 13.3" — the discontinued 5.7" also works), a microSD
card, and a computer with an SD slot or USB reader.

---

## 1. Flash the SD card, with headless settings baked in

1. Install **Raspberry Pi Imager** (raspberrypi.com/software).
2. Insert the card. **Choose Device** -> your Pi. **Choose OS** -> *Raspberry Pi
   OS Lite (64-bit)*, under "Raspberry Pi OS (other)". **Choose Storage** -> the
   card.
3. **Next -> Edit Settings**, which is what makes it work without a keyboard:
   - **Hostname:** `ident`
   - **Username and password:** e.g. `pilot`, and a password you will remember.
   - **Wireless LAN:** your SSID and password, country `GB`. On a Pi Zero this
     must be a **2.4GHz** network — the Zero cannot see 5GHz.
   - **Locale:** your timezone.
   - **Services** tab: **Enable SSH**, password authentication.
4. **Save**, then **Write**, then eject.

## 2. First boot, and finding it

Put the card in, seat the Inky on the header, power it on, and give it two
minutes. Then, from your computer:

```bash
ssh pilot@ident.local
```

If `.local` does not resolve, take the Pi's IP from your router's device list and
use that instead.

## 3. Enable SPI and I2C, and free the chip-select pin

The Inky needs both — I2C is how the panel is identified. The third line is not
optional either: Raspberry Pi OS claims GPIO8 as `spi0 CS0`, and the Inky wants
to drive that pin itself. Without it you get *"Woah there, some pins we need are
in use!"* and Ident stops before it draws anything.

```bash
sudo raspi-config nonint do_spi 0
sudo raspi-config nonint do_i2c 0
echo "dtoverlay=spi0-0cs" | sudo tee -a /boot/firmware/config.txt
sudo reboot
```

Wait a minute, then SSH back in.

## 4. System packages

```bash
sudo apt update && sudo apt full-upgrade -y
sudo apt install -y python3-venv python3-pip unzip fonts-dejavu-core python3-lgpio
```

`fonts-dejavu-core` is not optional — without it every label on the panel comes
out microscopic.

## 5. Copy the app across and install it

On **your computer**:

```bash
scp ~/Downloads/ident.zip pilot@ident.local:~/
```

Then on **the Pi**:

```bash
unzip -o ident.zip          # creates ~/ident
cd ident
python3 -m venv .venv --system-site-packages
source .venv/bin/activate
pip install -r requirements.txt
pip install -r requirements-epaper.txt    # inky + qrcode
pip install gpiozero                      # the four side buttons
```

Optional, and deliberately not in the base install: `pip install -r
requirements-pdf.txt` adds eCrew roster **PDF** reading. It pulls in pdfplumber,
pdfminer.six and cryptography — roughly half the product's dependency weight —
for a fallback that `.ics` upload already covers.

## 6. Start it

```bash
python -m ident.main
```

You should see two lines worth reading:

```
[ident] found a impression_4 panel (600x400, spectra6) - output set to e-paper
[ident] Inky detected: 600x400 (spectra6)
```

**There is nothing to configure by hand.** On first start Ident asks the panel
what it is, sets the output to e-paper and records the size, so the previews in
the control panel match what is actually on the wall. The numbers will be
`800x480` for the 7.3", `1600x1200` for the 13.3", and `600x448 (acep7)` for the
older 5.7".

If no panel is found Ident stays on the simulator and says so — check SPI and
I2C from step 3 before anything else.

## 7. Set it up from your phone

On your **phone**, on the same Wi-Fi:

```
http://ident.local:8080
```

The first time, you get the **setup wizard**. It is not optional: nothing else on
the device is reachable until it is finished. It asks for

- a **display style**. Only the styles your panel is big enough to draw are
  offered — the month calendar needs 7" or larger.
- a **display name**, your **base** (e.g. `LGW`) and **airline code** (`U2`)
- your **roster calendar URL**, if you have it to hand. It can be left blank and
  added afterwards.
- the timing sliders: commute, walk to the car, debrief, wake-up lead
- which **private roster codes**, if any, you want shown on the wall. Everything
  on that list — sickness, compassionate leave, disciplinary codes — is hidden by
  default and discarded when the roster is parsed, so it never reaches the
  device's storage at all.
- a **username and password**, at least six characters. This is required. The
  panel holds your roster and your calendar link, and that link is effectively a
  password for your whole schedule.

  Forgotten it? Put a file called `ident-reset.txt` on the SD card's boot
  partition and power the display on. It clears the password and deletes itself.

Press **Finish setup** and you land on the control panel: paste or upload a
roster and tap **Pull feed now**, change the style, upload an airline logo, move
the sliders. Everything is there — there is no settings file to edit.

Press `Ctrl+C` in the SSH window once you have confirmed the panel draws.

## 8. Make it start on boot

Paste this whole block at once:

```bash
sudo tee /etc/systemd/system/ident.service >/dev/null <<SERVICE
[Unit]
Description=Ident
After=network-online.target
Wants=network-online.target

[Service]
User=pilot
WorkingDirectory=/home/pilot/ident
ExecStart=/home/pilot/ident/.venv/bin/python -m ident.main
Restart=on-failure

[Install]
WantedBy=multi-user.target
SERVICE

sudo systemctl daemon-reload
sudo systemctl enable --now ident.service
```

Check it:

```bash
systemctl status ident.service
journalctl -u ident.service -f      # live logs; Ctrl+C to exit
```

That is it. It boots to the wall, repaints as the duty progresses, and you manage
it from `http://ident.local:8080`. No monitor, ever.

---

## Optional: a live drive time home

By default the journey home is the commute slider you set in the wizard. If you
would rather Ident asked how long the drive actually is, with traffic, put a
Google Maps API key and your home and car-park coordinates into *Advanced*, then
switch on **Live drive time home**.

It asks only while a home time is on the wall — in flight, on a turnaround, or
heading home — and no more often than the interval beside the switch (fifteen
minutes by default). A duty day therefore costs a dozen or so calls and a day
off costs none. If the lookup fails, the slider is used and nothing on the wall
changes. The Routes API is a paid Google Cloud product with a monthly free
credit; leave the switch off for a build that costs nothing to run.

## Updates

Ident checks `ident.xpdr.aero/releases/latest.json` once a day. A new release
installs **by itself** once it has been published for 72 hours, and never in the
middle of a duty — only on a day off or between duties. There is an **install
now** button in the control panel if you would rather not wait, and a switch to
turn the automatic part off. Every download is checked against a published
checksum and the running version is backed up first.

The 72-hour gate is the safety net: a bad release sits on the author's own panel
for three days before it can reach anyone else's wall.

---

## Troubleshooting

- **`ident.local` will not resolve:** use the Pi's IP from your router.
- **"Inky not detected":** re-check SPI *and* I2C (step 3). The I2C EEPROM is
  what identifies the panel.
- **Text is tiny:** `sudo apt install -y fonts-dejavu-core`, then
  `sudo systemctl restart ident`.
- **"Woah there, some pins we need are in use":** step 3's third line was
  missed. Add it and reboot.
- **Permission errors on SPI/GPIO:** the default user is already in the `spi`,
  `gpio` and `i2c` groups. A user you created yourself needs
  `sudo usermod -aG spi,gpio,i2c <user>` and a reboot.
- **The roster will not parse from the feed:** export a `.ics` from the crew
  portal and upload it in the control panel instead.
- **A style shows "needs a bigger panel":** the month calendar wants 700x420 or
  more, so it is not offered on a 4.0" or 5.7". If an older config still has it
  selected, pick another style in the control panel.

## Managing Wi-Fi from the web page (optional)

The control panel can store extra Wi-Fi networks — useful for pre-loading a
crashpad or hotel network before you travel. Saving a system network needs admin
rights, so grant it once:

```bash
echo "$USER ALL=(root) NOPASSWD: /usr/bin/nmcli" | sudo tee /etc/sudoers.d/ident-nmcli
sudo systemctl restart ident
```

Without that rule the card still appears, but saving returns a permission
message. Networks must be 2.4GHz on a Pi Zero.

If the display finds itself offline for two minutes it raises its own
`Ident-Setup` hotspot, so you can join that from a phone and point it at a new
network without touching a Terminal.
