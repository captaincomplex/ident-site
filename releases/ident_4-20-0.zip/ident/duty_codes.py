"""Duty codes, in one place — including the ones that shouldn't be displayed.

Some roster codes say something the rest of the room has no business reading off
a wall. Compassionate leave is the obvious one: the board is in a kitchen, and a
visitor shouldn't learn that a bereavement is in progress because a four-letter
code appeared on it. Resignation is another — that is news you deliver yourself,
in your own order, not something a wall breaks to whoever walks past.

Every code in ``DISCREET`` is **hidden by default** and shown as an ordinary day
off. The owner can reveal any of them individually during setup or later in
settings; nothing is revealed without being asked for.

Hiding happens **at parse time**, and the original code is not kept. That is
deliberate: a code that is never stored cannot leak through a display style added
in a future version, a diagnostics export, or a screenshot sent to support. The
cost is that revealing a code only affects rosters read after the change, which
is why the panel re-reads the feed when the setting is saved.

Both parsers import from here, so adding an airline's codes is one edit.
"""
from __future__ import annotations

import re

from .models import DutyType

_WORD = re.compile(r"[A-Z][A-Z0-9/]*")

PUBLIC_SUBSTITUTE = "D/O"

# code -> (label shown in the settings checklist, why it might matter)
DISCREET: dict[str, tuple[str, str]] = {
    # Bereavement and family
    "COMP":  ("Compassionate leave", "A bereavement or family crisis in progress."),
    "CMPU":  ("Compassionate leave, unpaid", "As above."),
    "MAT":   ("Maternity leave", "A pregnancy you may not have announced."),
    "PAT":   ("Paternity leave", "As above."),
    "PARL":  ("Parental leave", "As above."),
    # Health
    "SICK":  ("Sick", "Your health is nobody else's business."),
    "S/L":   ("Sick leave", "As above."),
    "MED":   ("Medical", "A routine medical and a licence problem look identical."),
    "LOL":   ("Loss of licence", "Career-threatening, and rarely settled news."),
    # Employment
    "RESN":  ("Resigned", "News you should deliver yourself, in your own order."),
    "TERM":  ("Termination", "As above, and worse."),
    "SUSP":  ("Suspended", "An allegation is not a finding."),
    "DISC":  ("Disciplinary", "As above."),
    "GRV":   ("Grievance", "Yours or someone else's — either way, private."),
    # Ambiguous by nature
    "MEET":  ("Meeting", "A management meeting and a disciplinary look the same."),
    "INT":   ("Interview", "A command board, or a job elsewhere."),
    "SOC":   ("Subject to operational clearance", "A request that may still be refused."),
    "UNPD":  ("Unpaid leave", "Often financial, occasionally not."),
    # Fatigue and availability. Added 11 Sep 2026 on Steven's instruction;
    # FTGD was previously mis-filed as a training code and shown on the wall.
    "FTGD":  ("Fatigued", "Reporting unfit through fatigue is a safety duty, not a failing \u2014 and still nobody else's business."),
    "NSO":   ("No show", "A no-show can precede a disciplinary, and an allegation is not a finding."),
    "NAVB":  ("Not available", "Why you are unavailable is nobody else's business."),
    "UNFT":  ("Unfit", "Unable to operate for a reason of your own. The reason is the private part."),
    "UNCT":  ("Uncontactable", "Says where you weren't and what was happening; neither is the room's business."),
}

# Wording that means the same thing when an airline spells it out in the summary.
DISCREET_PHRASES = (
    "compassionate", "bereavement", "subject to operational clearance",
    "parental leave", "maternity", "paternity", "sick leave", "resigned",
    "resignation", "suspended", "disciplinary", "grievance", "loss of licence",
    "loss of license", "termination", "no show", "not available",
    # "fatigued", not "fatigue": a fatigue-management *course* is training,
    # and hiding it as a day off would be wrong in the other direction.
    # "unfit" is deliberately absent for the same reason — it appears in
    # "unfit to fly" briefings and in training material about other people.
    "fatigued", "uncontactable",
)

# Which phrase belongs to which code, so revealing "SICK" also reveals an event
# that spells out "sick leave" rather than using the code.
_PHRASE_CODE = {
    "compassionate": "COMP", "bereavement": "COMP",
    "subject to operational clearance": "SOC",
    "parental leave": "PARL", "maternity": "MAT", "paternity": "PAT",
    "sick leave": "SICK", "resigned": "RESN", "resignation": "RESN",
    "suspended": "SUSP", "disciplinary": "DISC", "grievance": "GRV",
    "loss of licence": "LOL", "loss of license": "LOL", "termination": "TERM",
    "no show": "NSO", "not available": "NAVB", "fatigued": "FTGD",
    "uncontactable": "UNCT",
}

# Codes that are useful on the wall and carry nothing personal. Listed so the
# settings page can say plainly what is *not* being hidden.
ALWAYS_SHOWN = {
    "D/O": "Day off", "OFF": "Day off", "WFTU": "Work-free time unit",
    "AL": "Annual leave", "LVE": "Leave", "REST": "Rest day",
    "ADTY": "Airport standby", "APTD": "Airport standby",
    "ADUT": "Airport standby", "ASBY": "Airport standby",
    "ESBY": "Standby (home)", "HSBY": "Home standby", "PSBE": "Standby",
    "LSBY": "Late standby", "PSBL": "Late standby",
    "STBY": "Standby", "SBY": "Standby",
    "CSBE": "Standby", "CSBL": "Standby", "RSBY": "Standby",
    "UNN": "Union day",
    "SIM": "Simulator", "GS": "Groundschool", "EBTG": "EBT Groundschool",
    "LPC": "Licence proficiency check", "OPC": "Operator proficiency check",
    "OJT": "Line training", "CRM": "CRM course",
}

# Codes that mean "a day off" and should simply say so. WFTU is a work-free
# time unit — rostering's word for a day off, not something a household needs
# to decode off a wall. Annual leave keeps its own label because "I'm on leave"
# is genuinely different information from "I'm not working today".
SAME_AS_DAY_OFF = {"WFTU", "DO", "OFF", "REST", "RD", "X"}


def normalise(code: str) -> str:
    """The label to display for a non-flying code.

    Matches on tokens, so "WFTU" and "WFTU Work free time unit" both come out
    as a plain day off — airlines are inconsistent about whether the summary is
    the bare code or the code plus its expansion.
    """
    raw = (code or "").strip()
    if not raw:
        return raw
    if raw.upper() in SAME_AS_DAY_OFF:
        return PUBLIC_SUBSTITUTE
    toks = _WORD.findall(raw.upper())
    return PUBLIC_SUBSTITUTE if (toks and toks[0] in SAME_AS_DAY_OFF) else raw


# These four sets, and the phrase lists under them, are what both parsers now
# use. Adding an airline's code is an edit here and nowhere else — which is
# what this module's docstring has always claimed, and from 11 Sep 2026 is
# actually true. Codes are matched on whole tokens; the phrases are for
# airlines that spell the duty out in the summary instead.
OFF_CODES = {"D/O", "DO", "OFF", "WFTU", "AL", "LVE", "REST", "RD", "X"}
STANDBY_CODES = {"PSBE", "PSBL", "ESBY", "LSBY", "ASBY", "HSBY", "STBY", "SBY",
                 "ADTY", "APTD", "ADUT",
                 # Named by Steven, 18 Sep 2026, as easyJet codes that were
                 # missing, and confirmed by him the same day as **home**
                 # standby - so deliberately absent from AIRPORT_STANDBY_CODES
                 # below. Not an oversight: putting one of these at the field
                 # would draw a drive home for somebody already in the house.
                 "CSBE", "CSBL", "RSBY"}
# Airport standby specifically. Materially different to home standby: you are
# at the field, in uniform, and there is a drive home at the end of it.
AIRPORT_STANDBY_CODES = {"ADTY", "APTD", "ADUT", "ASBY"}
TRAINING_CODES = {"SIM", "GS", "OJT", "LPC", "OPC", "CRM", "EBTG"}
# Working days that are none of the above. A union day is work, not a day off
# and not flying, so it shows as a duty carrying its own code.
OTHER_CODES = {"UNN"}

OFF_PHRASES = ("day off", "day-off", "rest day", "off duty", "annual leave",
               "leave")
AIRPORT_STANDBY_PHRASES = ("airport standby", "airport duty", "apt duty")
HOME_STANDBY_PHRASES = ("standby", "stand by", "reserve", "home standby")
# "ground duty" is deliberately absent: FTGD turned out not to be training at
# all, so the wording is no longer evidence of one. An unrecognised ground
# duty now falls through to OTHER and shows its own code, which is honest.
TRAINING_PHRASES = ("training", "ground school", "groundschool", "recurrent",
                    "simulator")
# "union" alone is too broad; the wordings airlines actually use are not.
OTHER_PHRASES = ("union day", "union duties", "union meeting")

# An aircraft type welded onto a standby code - "ESBY321" for an A321-specific
# standby. Only ever stripped when what is left is a code we already know, so a
# genuine three-letter destination can never be turned into a duty this way.
#
# TODO (18 Sep 2026): the shape of these is a guess. Steven could not find a
# real example to hand, so this covers "<CODE>321" and nothing else. If easyJet
# writes them "ESBY 321" the code half already matches on its own; if it writes
# them "321 ESBY" the same is true; but anything else - a dash, a slash, a
# different fleet number - falls through and the duty is not read as standby.
# Replace this guess with a real roster line when one turns up.
_FLEET_SUFFIX = re.compile(r"^([A-Z]{3,4})(?:319|320|321|32N|32Q)$")


def _tokens(text: str) -> set[str]:
    toks = set(_WORD.findall((text or "").upper()))
    for tok in list(toks):
        m = _FLEET_SUFFIX.match(tok)
        if m:
            toks.add(m.group(1))
    return toks


def is_airport_standby(text: str) -> bool:
    """True when this duty is standby *at the airport* rather than at home.

    Codes are token-matched, never substring: "ASBY" must not be found inside
    a word. Spelled-out wording is matched as a phrase.
    """
    if AIRPORT_STANDBY_CODES & _tokens(text):
        return True
    low = (text or "").lower()
    return any(p in low for p in AIRPORT_STANDBY_PHRASES)


def matched_code(text: str) -> str | None:
    """Which private code this duty is, or None if it isn't one.

    Codes are matched on whole tokens, never substrings: "COMP" must not be
    found inside "COMPLETED", and "MED" must not match "MEDITERRANEAN".
    """
    low = (text or "").lower()
    for phrase, code in _PHRASE_CODE.items():
        if phrase in low:
            return code
    hit = _tokens(text) & set(DISCREET)
    if hit:
        # Deterministic when a summary somehow contains two.
        return sorted(hit)[0]
    return None


def is_discreet(text: str, show: "set[str] | list[str] | None" = None) -> bool:
    """Should this duty be shown as a plain day off?

    ``show`` is the set of codes the owner has chosen to reveal.
    """
    code = matched_code(text)
    if code is None:
        return False
    allowed = {c.upper() for c in (show or ())}
    return code not in allowed


def public_code(raw: str, show=None) -> str:
    """What may be shown. Hidden codes become an ordinary day off."""
    return PUBLIC_SUBSTITUTE if is_discreet(raw, show) else (raw or "")


def classify(text: str, show=None) -> DutyType | None:
    """Duty type from a code or summary, or None if it isn't recognised.

    Both parsers call this. It must never be asked about a flying duty: a
    dozen duty codes are also real IATA airport codes (MED is Medina, SIM is
    Simara, SBY is Saliba), so a sector to one of them would be read as a day
    off. Identify the flight first, then ask this about what's left.
    """
    if matched_code(text) is not None:
        # Whether or not it's revealed, these are days you aren't flying.
        return DutyType.DAY_OFF
    toks = _tokens(text)
    low = (text or "").lower()
    if toks & OFF_CODES or any(p in low for p in OFF_PHRASES):
        return DutyType.DAY_OFF
    if toks & STANDBY_CODES or any(
            p in low for p in AIRPORT_STANDBY_PHRASES + HOME_STANDBY_PHRASES):
        return DutyType.STANDBY
    if toks & TRAINING_CODES or any(p in low for p in TRAINING_PHRASES):
        return DutyType.TRAINING
    if toks & OTHER_CODES or any(p in low for p in OTHER_PHRASES):
        return DutyType.OTHER
    return None


def checklist() -> list[tuple[str, str, str]]:
    """(code, label, why) for the settings UI, in a sensible reading order."""
    return [(c, DISCREET[c][0], DISCREET[c][1]) for c in DISCREET]
