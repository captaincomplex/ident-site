"""The day-off album, sent from a Mac through the control panel (19 Sep 2026).

Until now the Mac script mirrored the album with SSH and `rsync --delete`
straight into Ident's data folder. That stopped working on the SD image, where
Ident runs as its own `ident` account: the owner's login cannot write into
Ident's folder, and a customer image has no SSH unless the owner added a key.

So the Mac talks to the control panel instead, over the home network:

  GET    /api/album/sync          which pictures the Pi has, and the album name
  PUT    /api/album/sync/<name>   add one picture
  DELETE /api/album/sync/<name>   remove one picture

The Mac works out the difference and sends only that, so a picture added to
the album appears on the wall and one taken out leaves it - the same mirror
rsync gave, with nothing else on the device reachable.

Those three calls are authorised by a PAIRING CODE, not the panel password.
The panel issues it once, the Mac keeps it in its Keychain, and the device
stores only a hash of it. The code can change the album and nothing else:
not the roster link, not the settings, not the password. A Mac that is lost
or sold is cut off by pressing Unpair, without changing the panel password.

Nothing passes through a server. The Mac sends straight to the Pi, which is
the rule the roster follows.
"""
from __future__ import annotations

import hashlib
import hmac
import io
import os
import re
import secrets

from . import config as _config

# <Photos UUID>-<first 8 hex of the picture's SHA-256>.jpg from the Mac script.
# The hash is in the name so an edited photo - same UUID, new pixels - arrives
# as a new file and the old version leaves. Deliberately narrow: no dots before
# the extension, no slashes, nothing that could climb out of the album folder.
NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_-]{0,99}\.jpg$")

# An SD card is not a photo library. Enough for more than a year of days off.
MAX_PHOTOS = 500
# Re-encoded to this on the way in, whatever the Mac sent. Matches the single
# day-off picture upload.
MAX_EDGE = 2400


class SyncError(ValueError):
    """Refused, with a message fit to show the person running the sync."""


# ---------- the pairing code ----------

def new_code() -> str:
    """A fresh pairing code: 32 URL-safe characters, 192 bits of randomness."""
    return secrets.token_urlsafe(24)


def code_hash(code: str) -> str:
    # A plain SHA-256 is enough here and a slow hash would be wrong: the code is
    # 192 random bits, not a password a person chose, so there is nothing to
    # guess. Only the hash is stored, so the config file does not hold the key.
    return hashlib.sha256(code.encode("utf-8")).hexdigest()


def code_ok(cfg, presented: str) -> bool:
    stored = (getattr(cfg, "album_sync_code_hash", "") or "").strip()
    if not stored or not presented:
        return False
    return hmac.compare_digest(stored, code_hash(presented.strip()))


def bearer(auth_header: str) -> str:
    """The code from an ``Authorization: Bearer <code>`` header, or ""."""
    parts = (auth_header or "").split(None, 1)
    return parts[1].strip() if len(parts) == 2 and parts[0].lower() == "bearer" else ""


# ---------- the album folder ----------

def album_dir() -> str:
    # Read at call time, not import time, so it follows IDENT_DATA.
    return _config.ALBUM_DIR


def valid_name(name: str) -> bool:
    return bool(NAME_RE.match(name or ""))


def manifest() -> list:
    """Every picture this API manages, sorted."""
    try:
        return sorted(n for n in os.listdir(album_dir()) if valid_name(n))
    except OSError:
        return []


def store(name: str, data: bytes) -> tuple:
    """Save one picture into the album. Returns its (width, height).

    Re-encoded, never stored as sent: that drops EXIF (location, camera, time)
    and guarantees the panel is only ever handed a real picture. Written to a
    hidden temporary file and renamed into place, so the renderer - which
    ignores dot-files - never sees half a picture.
    """
    if not valid_name(name):
        raise SyncError(f"Not a valid picture name: {name!r}")
    d = album_dir()
    os.makedirs(d, exist_ok=True)
    final = os.path.join(d, name)
    if not os.path.exists(final) and len(manifest()) >= MAX_PHOTOS:
        raise SyncError(f"The album on the display is full ({MAX_PHOTOS} pictures).")
    try:
        from PIL import Image, ImageOps
        img = Image.open(io.BytesIO(data))
        img.load()
        img = ImageOps.exif_transpose(img)
    except Exception:
        raise SyncError("That isn't a picture the display can read.")
    if img.mode != "RGB":
        img = img.convert("RGB")
    img.thumbnail((MAX_EDGE, MAX_EDGE), Image.LANCZOS)
    tmp = os.path.join(d, f".incoming-{secrets.token_hex(4)}.jpg")
    try:
        img.save(tmp, "JPEG", quality=88)
        os.replace(tmp, final)
    finally:
        if os.path.exists(tmp):
            try:
                os.remove(tmp)
            except OSError:
                pass
    return img.size


def remove(name: str) -> bool:
    """Take one picture out of the album. False if it was not there."""
    if not valid_name(name):
        raise SyncError(f"Not a valid picture name: {name!r}")
    try:
        os.remove(os.path.join(album_dir(), name))
        return True
    except FileNotFoundError:
        return False
