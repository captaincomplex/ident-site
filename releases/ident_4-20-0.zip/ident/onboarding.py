"""Wi-Fi onboarding without a keyboard, a laptop or a Terminal.

If the device boots and can't get onto a network, it raises its own hotspot.
The owner joins that from a phone, picks their home network from a list and
types the password. No Imager settings, no SSH, no typing of commands.

That hotspot has a fixed, published password of its own (``AP_PASSWORD``).
It must be passed to nmcli explicitly: given none, nmcli generates a random
key that is never displayed anywhere, and the owner is locked out of their
own device.

Only 2.4GHz networks are offered on hardware that can't see 5GHz (the Pi Zero
2 W), because listing a network the radio physically cannot join is the single
most reliable way to waste somebody's evening.
"""
from __future__ import annotations

import os
import subprocess
import time

AP_SSID = "Ident-Setup"
AP_CON = "ident-setup-ap"
AP_ADDR = "10.42.0.1"

# The setup hotspot's own password, fixed and published in the setup guide.
#
# It has to be set explicitly. Given no password, nmcli invents a random one
# and stores it in the connection profile - and nothing ever shows that key to
# the owner, not the panel and not the guide, so the hotspot the customer is
# told to join cannot be joined. A customer dry run on 13-14 September stopped
# dead there.
#
# It is deliberately not a secret: it protects nothing (the setup page refuses
# to take the roster link or the panel password over the hotspot - see
# web/app.py), and its only job is to keep the device off an open network and
# out of reach of a passing phone that joins by accident.
#
# WPA2-PSK passphrases are 8..63 characters, which is why this is not "ident".
AP_PASSWORD = "identsetup"


HELPER = "/usr/local/sbin/ident-wifi"


def _helper_available() -> bool:
    return os.path.isfile(HELPER) and os.access(HELPER, os.X_OK)


def _via_helper(action: str, *args, timeout: int = 60):
    """Run one fixed action through the privileged helper.

    The helper validates its own arguments and exposes only a small set of
    operations, so the panel never gets general-purpose root nmcli access.
    """
    try:
        r = subprocess.run(["sudo", "-n", HELPER, action, *args],
                           capture_output=True, text=True, timeout=timeout)
        return r.returncode == 0, (r.stdout or r.stderr or "").strip()
    except Exception as e:
        return False, str(e)


def _nm(args, timeout=25):
    from .wifi import _run
    return _run(args, timeout=timeout)


# ---------- state ----------

def is_online() -> bool:
    """True when NetworkManager reports full or limited connectivity."""
    if _helper_available():
        ok, out = _via_helper("connectivity", timeout=20)
        if ok and out.strip() in ("full", "portal", "limited"):
            return True
        ok, out = _via_helper("status", timeout=20)
        return ok and out.strip().startswith("connected")
    ok, out = _nm(["-t", "networking", "connectivity", "check"])
    if ok and out.strip() in ("full", "portal", "limited"):
        return True
    ok, out = _nm(["-t", "-f", "STATE", "general", "status"])
    return ok and out.strip().startswith("connected")


def ap_active() -> bool:
    if _helper_available():
        ok, out = _via_helper("hotspot-active", timeout=20)
    else:
        ok, out = _nm(["-t", "-f", "NAME", "connection", "show", "--active"])
    return ok and AP_CON in out.split("\n")


# ---------- scanning ----------

def parse_scan(raw: str, only_24ghz: bool = True) -> list[dict]:
    """Turn `nmcli -t -f SSID,FREQ,SIGNAL,SECURITY device wifi list` into dicts.

    Sorted strongest first, one entry per SSID. 5GHz rows are dropped when the
    radio can't use them, so the list only shows joinable networks.
    """
    seen: dict[str, dict] = {}
    for line in (raw or "").splitlines():
        # nmcli escapes colons inside fields as '\:' - split on unescaped ones
        parts, buf, esc = [], "", False
        for ch in line:
            if esc:
                buf += ch; esc = False
            elif ch == "\\":
                esc = True
            elif ch == ":":
                parts.append(buf); buf = ""
            else:
                buf += ch
        parts.append(buf)
        if len(parts) < 3:
            continue
        ssid = parts[0].strip()
        if not ssid:
            continue
        try:
            freq = int("".join(c for c in parts[1] if c.isdigit()) or 0)
            signal = int("".join(c for c in parts[2] if c.isdigit()) or 0)
        except ValueError:
            continue
        band24 = freq < 3000
        if only_24ghz and not band24:
            continue
        sec = parts[3].strip() if len(parts) > 3 else ""
        prev = seen.get(ssid)
        if prev is None or signal > prev["signal"]:
            seen[ssid] = {"ssid": ssid, "signal": signal, "band": "2.4GHz" if band24 else "5GHz",
                          "secure": bool(sec and sec != "--")}
    return sorted(seen.values(), key=lambda n: -n["signal"])


def radio_is_24ghz_only() -> bool:
    """Pi Zero 2 W and Zero W have 2.4GHz-only radios."""
    try:
        model = open("/proc/device-tree/model", "rb").read().decode(errors="ignore")
    except Exception:
        return False
    m = model.lower()
    return "zero 2 w" in m or ("zero w" in m and "zero 2" not in m)


def scan(force_all: bool = False) -> list[dict]:
    if _helper_available():
        ok, out = _via_helper("scan", timeout=45)
    else:
        _nm(["device", "wifi", "rescan"], timeout=30)
        ok, out = _nm(["-t", "-f", "SSID,FREQ,SIGNAL,SECURITY", "device", "wifi", "list"], timeout=30)
    if not ok:
        return []
    return parse_scan(out, only_24ghz=(not force_all) and radio_is_24ghz_only())


# ---------- hotspot ----------

def start_ap() -> tuple[bool, str]:
    if ap_active():
        return True, "already running"
    if _helper_available():
        ok, out = _via_helper("hotspot-up")
        return (True, AP_SSID) if ok else (False, out)
    _nm(["connection", "delete", AP_CON])
    ok, out = _nm(["device", "wifi", "hotspot", "ifname", "wlan0",
                   "con-name", AP_CON, "ssid", AP_SSID,
                   "password", AP_PASSWORD])
    if not ok:
        return False, out
    _nm(["connection", "modify", AP_CON, "connection.autoconnect", "no"])
    return True, AP_SSID


def stop_ap() -> None:
    if _helper_available():
        _via_helper("hotspot-down")
        return
    _nm(["connection", "down", AP_CON])
    _nm(["connection", "delete", AP_CON])


def join(ssid: str, password: str = "") -> tuple[bool, str]:
    """Join a network, dropping the hotspot first so the radio is free."""
    ssid = (ssid or "").strip()
    if not ssid:
        return False, "Choose a network."
    if password and len(password) < 8:
        return False, "Wi-Fi passwords are at least 8 characters."
    was_ap = ap_active()
    if was_ap:
        stop_ap(); time.sleep(2)
    if _helper_available():
        ok, out = _via_helper("connect", ssid, password) if password \
            else _via_helper("connect", ssid)
    else:
        args = ["device", "wifi", "connect", ssid]
        if password:
            args += ["password", password]
        ok, out = _nm(args, timeout=60)
    if ok:
        return True, f"Connected to {ssid}."
    if was_ap:                       # failed - put the hotspot back so we stay reachable
        time.sleep(1); start_ap()
    return False, out or "Could not connect. Check the password."
