"""Self-updating: check GitHub Releases, verify, install.

The device *pulls* updates - it checks a public Releases feed over HTTPS on a
schedule, so nothing needs to reach in from outside and there is no server to
run. Nothing personal is sent; the only request is an unauthenticated GET of
the releases endpoint.

An update is applied only when asked for (from the panel), never silently:

  1. download the release's zip asset to a temp file
  2. check its SHA-256 against the digest published in the release notes
     (a line reading  sha256: <hex>  ), when one is present
  3. unpack to a staging dir and sanity-check it imports
  4. back up the current app (into <app>/.backup), swap the new one in, and
     restart by exiting - systemd's Restart= brings the service back

If any step fails the running install is left untouched.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import urllib.request
import zipfile

# Updates are published as a plain file on the website, not through the GitHub
# Releases API. The source repository is private, and the API returns 404 to
# anonymous callers on a private repo — which would have silently broken the
# updater on every device in the field. A static JSON file on ident.xpdr.aero
# needs no token, no account, and no rate limit.
MANIFEST_URL = "https://ident.xpdr.aero/releases/latest.json"

# Kept as a fallback so devices running an older build, which only know how to
# ask GitHub, keep working if the repository is ever public again.
RELEASES_API = "https://api.github.com/repos/{repo}/releases/latest"
DEFAULT_REPO = "captaincomplex/ident"
UA = {"User-Agent": "ident-updater"}


def _ver_tuple(v: str):
    return tuple(int(x) for x in re.findall(r"\d+", v or "")[:3] or [0])


def is_newer(remote: str, local: str) -> bool:
    return _ver_tuple(remote) > _ver_tuple(local)


def _licence_headers() -> dict:
    """The licence key, if this install has one, as a request header.

    Sent on the update check and the download so the far end *can* require a
    key. Nothing requires one today: an install with no key sends no header and
    is served exactly as before. Putting it in now means switching the server
    side on later does not need a release to reach every device first — which
    it would, and devices that could not update would be the ones stuck.
    """
    try:
        from .config import Config
        key = (Config.load().licence_key or "").strip()
        return {"X-Ident-Licence": key} if key else {}
    except Exception:
        return {}


def _get_json(url: str, timeout: int):
    req = urllib.request.Request(url, headers={**UA, **_licence_headers()})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.load(r)


def check(repo: str = DEFAULT_REPO, timeout: int = 20) -> dict:
    """Look up the latest release. Returns a dict; never raises."""
    from . import __version__
    out = {"ok": False, "current": __version__, "latest": "", "update_available": False,
           "url": "", "notes": "", "error": ""}

    # Preferred: the manifest on the website.
    try:
        data = _get_json(MANIFEST_URL, timeout)
        tag = str(data.get("version") or "").lstrip("vV")
        url = str(data.get("url") or "")
        sha = str(data.get("sha256") or "")
        if tag and url:
            notes = str(data.get("notes") or "")
            if sha and "sha256" not in notes.lower():
                notes = (notes + f"\n\nsha256: {sha}").strip()
            return {"ok": True, "current": __version__, "latest": tag, "url": url,
                    "notes": notes, "error": "",
                    "released": str(data.get("released") or ""),
                    "update_available": is_newer(tag, __version__)}
    except Exception as e:
        out["error"] = str(e)

    # Fallback: the GitHub Releases API, for as long as it answers.
    try:
        req = urllib.request.Request(RELEASES_API.format(repo=repo), headers=UA)
        with urllib.request.urlopen(req, timeout=timeout) as r:
            data = json.load(r)
        tag = (data.get("tag_name") or "").lstrip("vV")
        notes = data.get("body") or ""
        asset = ""
        for a in data.get("assets", []):
            if (a.get("name") or "").endswith(".zip"):
                asset = a.get("browser_download_url", "")
                break
        if not asset:
            asset = data.get("zipball_url", "")
        out.update(ok=True, latest=tag, url=asset, notes=notes,
                   update_available=is_newer(tag, __version__))
    except Exception as e:
        out["error"] = str(e)
    return out


def _sha256_from_notes(notes: str) -> str:
    m = re.search(r"sha256[:=]\s*([0-9a-fA-F]{64})", notes or "")
    return m.group(1).lower() if m else ""


# Where a release may come from. The manifest is fetched over HTTPS, but its
# contents decide what gets downloaded and executed — and `update_repo` is a
# config value. Without this, anyone able to write config and make the manifest
# fetch fail could have a chosen archive installed and run. Full signing is the
# proper answer; this is the cheap part of it.
ALLOWED_UPDATE_HOSTS = ("ident.xpdr.aero", "github.com", "objects.githubusercontent.com",
                        "codeload.github.com")


def is_allowed_update_url(url: str) -> bool:
    from urllib.parse import urlparse
    try:
        u = urlparse(url or "")
    except Exception:
        return False
    if u.scheme != "https":
        return False
    host = (u.hostname or "").lower()
    return any(host == h or host.endswith("." + h) for h in ALLOWED_UPDATE_HOSTS)


# Exit status used to ask systemd for a restart. Non-zero, so that installs
# from before 4.16.0 - whose unit says Restart=on-failure rather than
# Restart=always - come back too. 75 is EX_TEMPFAIL: "try again".
RESTART_EXIT_CODE = 75
RESTART_DELAY_S = 3.0


def _restart(service: str) -> None:
    """Get the newly installed code running.

    Under systemd, which sets INVOCATION_ID for every service it starts, exit
    and let the unit's Restart= bring the service back on the new code. That
    needs no privileges. The old way, `sudo systemctl restart`, could not work
    on the SD image, where Ident runs as an account with no sudo at all, and
    on a manual install it worked only if that user's sudo asked for no
    password - otherwise sudo gave up for want of a terminal, the files
    changed and the running code did not. The short delay
    lets the panel request that asked for the update receive its answer.

    Outside systemd - someone running Ident by hand - fall back to asking
    systemd, without prompting.
    """
    if os.environ.get("INVOCATION_ID"):
        t = threading.Timer(RESTART_DELAY_S, os._exit, args=(RESTART_EXIT_CODE,))
        t.daemon = True
        t.start()
    else:
        subprocess.Popen(["sudo", "-n", "systemctl", "restart", service])


def install(url: str, expect_sha: str = "", app_dir: str = "",
            service: str = "ident", timeout: int = 120) -> dict:
    """Download, verify and swap in a new version. Returns {'ok', 'error'}."""
    if not is_allowed_update_url(url):
        return {"ok": False, "error": f"Refusing to install from {url!r}"}
    app_dir = app_dir or os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    tmp = tempfile.mkdtemp(prefix="ident-update-")
    try:
        zpath = os.path.join(tmp, "update.zip")
        req = urllib.request.Request(url, headers={**UA, **_licence_headers()})
        with urllib.request.urlopen(req, timeout=timeout) as r, open(zpath, "wb") as f:
            shutil.copyfileobj(r, f)

        if expect_sha:
            h = hashlib.sha256()
            with open(zpath, "rb") as f:
                for chunk in iter(lambda: f.read(1 << 20), b""):
                    h.update(chunk)
            if h.hexdigest().lower() != expect_sha.lower():
                return {"ok": False, "error": "Checksum mismatch - update refused"}

        stage = os.path.join(tmp, "stage")
        with zipfile.ZipFile(zpath) as z:
            for name in z.namelist():                    # guard against path escapes
                p = os.path.normpath(os.path.join(stage, name))
                if not p.startswith(os.path.abspath(stage)):
                    return {"ok": False, "error": f"Unsafe path in archive: {name}"}
            z.extractall(stage)

        # find the package root inside the archive (…/ident/ident/__init__.py)
        src = ""
        for root, dirs, files in os.walk(stage):
            if os.path.basename(root) == "ident" and "__init__.py" in files \
               and "render" in dirs:
                src = os.path.dirname(root)
                break
        if not src:
            return {"ok": False, "error": "Archive did not contain an ident package"}

        # sanity-check the new code before swapping it in
        chk = subprocess.run([sys.executable, "-c",
                              "import sys;sys.path.insert(0,%r);import ident;print(ident.__version__)" % src],
                             capture_output=True, text=True, timeout=60)
        if chk.returncode != 0:
            return {"ok": False, "error": "New version failed to import: " + chk.stderr.strip()[:200]}

        # Inside the app folder, not beside it. Beside it was /opt/ident.backup
        # on the SD image, and /opt belongs to root: every update on an
        # image-installed device died here with "Permission denied" before
        # touching anything. The app folder is the one place this process is
        # guaranteed to be able to write, on every kind of install.
        backup = os.path.join(app_dir, ".backup")
        shutil.rmtree(backup, ignore_errors=True)
        shutil.copytree(os.path.join(app_dir, "ident"), os.path.join(backup, "ident"))
        for item in os.listdir(src):
            s = os.path.join(src, item); d = os.path.join(app_dir, item)
            if os.path.isdir(s):
                shutil.rmtree(d, ignore_errors=True); shutil.copytree(s, d)
            else:
                shutil.copy2(s, d)

        _restart(service)
        return {"ok": True, "version": chk.stdout.strip(), "backup": backup}
    except Exception as e:
        return {"ok": False, "error": str(e)}
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
