"""Diagnostics export — everything support needs, nothing they shouldn't have.

Produces a plain-text report the owner can read in full before sending. That
matters: the point of Ident is that a roster never leaves the device, so the
support path must not quietly undo it.

Redacted, never included:
  * the iCal URL          - it is a bearer secret; anyone holding it can read
                            the whole roster. Only the host is shown.
  * API keys and tokens   - tracker, maps, Vestaboard
  * the panel password    - not even the hash
  * Wi-Fi passwords       - never read; only network names and signal
  * passenger/crew names  - the roster summary is counts and codes only
"""
from __future__ import annotations

import datetime as dt
import os
import platform
import re
import shutil
import subprocess

SECRET_KEYS = ("ical_url", "google_maps_api_key", "aerodatabox_key", "fr24_api_token",
               "vestaboard_rw_key", "auth_password_hash", "licence_key",
               "album_sync_code_hash")


def _run(cmd, timeout=10) -> str:
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return (r.stdout or r.stderr or "").strip()
    except Exception as e:
        return f"(unavailable: {e})"


def _redact_url(url: str) -> str:
    """Keep the host so we can spot a wrong provider; drop the secret path."""
    if not url:
        return "(not set)"
    try:
        from urllib.parse import urlparse
        u = urlparse(url)
        return f"{u.scheme}://{u.netloc}/… ({len(url)} chars, path and query hidden)"
    except Exception:
        return "(set, hidden)"


_URL_RE = re.compile(r"(https?://[^\s\"\'<>]+)")


def _scrub(line: str) -> str:
    """Take any URL path out of a log line.

    The config section redacts the iCal URL properly, and then the log section
    used to hand it straight back: a failing feed logs an exception, and
    requests puts the whole URL — token and all — in the message. That is the
    single most likely line to appear right before a customer downloads this
    file and emails it to us.
    """
    def _redact(m):
        u = m.group(1)
        try:
            from urllib.parse import urlparse
            parsed = urlparse(u)
            return f"{parsed.scheme}://{parsed.netloc}/… (path hidden)"
        except Exception:
            return "(url hidden)"
    return _URL_RE.sub(_redact, line)


def _config_section(cfg) -> list[str]:
    out = []
    for field in sorted(getattr(cfg, "__annotations__", {})):
        val = getattr(cfg, field, None)
        if field == "ical_url":
            val = _redact_url(val)
        elif field in SECRET_KEYS:
            val = "(set, hidden)" if val else "(not set)"
        out.append(f"  {field:26} {val}")
    return out


def _roster_section() -> list[str]:
    try:
        from .config import load_roster
        r = load_roster()
    except Exception as e:
        return [f"  could not load roster: {e}"]
    if not r.duties:
        return ["  no roster loaded"]
    kinds: dict[str, int] = {}
    for d in r.duties:
        k = getattr(d.duty_type, "value", str(d.duty_type))
        kinds[k] = kinds.get(k, 0) + 1
    ds = sorted(d.date for d in r.duties)
    sectors = sum(len(d.sectors) for d in r.duties)
    return ([f"  base                       {r.base or '(unset)'}",
             f"  duties                     {len(r.duties)}",
             f"  sectors                    {sectors}",
             f"  date range                 {ds[0]} to {ds[-1]}"]
            + [f"  {('type ' + k):26} {v}" for k, v in sorted(kinds.items())]
            + ["  (crew names and flight details are deliberately not included)"])


def collect() -> str:
    from . import __version__
    from .config import Config, DATA_DIR
    now = dt.datetime.now(dt.timezone.utc)
    L = [f"IDENT DIAGNOSTICS  —  {now:%Y-%m-%d %H:%M} UTC",
         "=" * 62,
         "Safe to send to support. Your roster, passwords, API keys and Wi-Fi",
         "passwords are not included. Read it through before sending if unsure.",
         ""]

    try:
        cfg = Config.load()
    except Exception as e:
        cfg = None
        L += [f"CONFIG FAILED TO LOAD: {e}", ""]

    L += ["VERSION & SYSTEM", "-" * 62,
          f"  ident version              {__version__}",
          f"  python                     {platform.python_version()}",
          f"  platform                   {platform.platform()}"]
    try:
        L.append(f"  model                      {open('/proc/device-tree/model').read().strip(chr(0))}")
    except Exception:
        L.append("  model                      (not a Raspberry Pi)")
    L += [f"  uptime                     {_run(['uptime', '-p'])}",
          f"  data dir                   {DATA_DIR}",
          f"  disk free                  {shutil.disk_usage('/').free // (1024**2)} MB", ""]

    if cfg:
        L += ["CONFIGURATION (secrets removed)", "-" * 62] + _config_section(cfg) + [""]

    L += ["ROSTER (summary only)", "-" * 62] + _roster_section() + [""]

    L += ["DISPLAY", "-" * 62]
    cache = os.path.join(DATA_DIR, "coastline.json")
    L.append(f"  coastline cache            {'present, %d KB' % (os.path.getsize(cache)//1024) if os.path.exists(cache) else 'not downloaded yet'}")
    try:
        from .render.epaper import PANELS
        L.append(f"  known panels               {', '.join(PANELS)}")
    except Exception as e:
        L.append(f"  renderer import failed     {e}")
    L.append("")

    L += ["NETWORK (no passwords)", "-" * 62,
          f"  hostname                   {platform.node()}",
          f"  connectivity               {_run(['nmcli', '-t', 'networking', 'connectivity', 'check'])}",
          f"  active connection          {_run(['nmcli', '-t', '-f', 'NAME,TYPE', 'connection', 'show', '--active'])}"]
    try:
        from .onboarding import scan, radio_is_24ghz_only
        L.append(f"  radio is 2.4GHz only       {radio_is_24ghz_only()}")
        nets = scan()
        L.append(f"  visible networks           {len(nets)}")
        for n in nets[:6]:
            L.append(f"    {n['ssid'][:28]:30} {n['signal']:3}%  {n['band']}")
    except Exception as e:
        L.append(f"  scan unavailable           {e}")
    L.append("")

    L += ["SERVICE", "-" * 62,
          f"  ident.service              {_run(['systemctl', 'is-active', 'ident.service'])}",
          f"  enabled at boot            {_run(['systemctl', 'is-enabled', 'ident.service'])}", ""]

    L += ["RECENT LOG", "-" * 62]
    log = _run(["journalctl", "-u", "ident.service", "-n", "60", "--no-pager"], timeout=20)
    L += ["  " + _scrub(ln) for ln in log.splitlines()[-60:]] or ["  (no log available)"]
    L += ["", "=" * 62, "End of report."]
    return "\n".join(L)
