"""Renderer interface. A renderer takes a Screen and shows it somewhere."""
from __future__ import annotations

from typing import Protocol

from .presenter import Screen


class Renderer(Protocol):
    def show(self, screen: Screen) -> None:
        ...

    def clear(self) -> None:
        ...

    def apply_config(self, cfg) -> None:
        """Take display options from the live config, every tick.

        Without this a renderer keeps whatever it was built with, and every
        setting on the control panel silently stops at the preview: picking a
        new style changed the config and the preview image and left the wall
        drawing the old one until the service restarted. Renderers with nothing
        to re-read may leave this as a no-op.
        """
        ...


def hex_to_rgb(h: str) -> tuple[int, int, int]:
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))
