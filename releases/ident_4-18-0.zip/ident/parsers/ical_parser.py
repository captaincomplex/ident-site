"""Parse an iCal feed (AIMS eCrew export, surfaced via Google Calendar) -> Roster.

Format learned from a real AIMS eCrew event:

    SUMMARY:     8301 LGW-MXP
    DTSTART/END: 05:40 - 08:55          (report time -> arrival; NOT the STD)
    LOCATION:    (0555Z-0755Z) LGW      (block time in UTC, + departure station)
    DESCRIPTION: Reporting time : 0540
                 8301  - LGW  (0655) - MXP  (0855)
                 * All times in Local Base (LGW)

The DESCRIPTION is authoritative for sector times (Local Base), so we parse it
rather than trusting DTSTART (which is padded to the reporting time on the first
sector). LOCATION's Zulu times are kept as a cross-check / fallback. Each VEVENT
is one sector; sectors are grouped into duties by time gap, and the duty's
report comes from the 'Reporting time' line.

Non-flying events (standby / day off / training) are classified by keyword; the
exact wording AIMS uses for those is the one remaining unknown, so the keyword
lists below are easy to extend.
"""
from __future__ import annotations

import datetime as dt
import re
from typing import Optional

from .. import duty_codes as _codes
from ..models import Duty, DutyType, Roster, Sector
from ..timezones import base_local_to_utc

_RE_FLIGHT_LINE = re.compile(
    r"(\d{2,4})\s*-\s*([A-Z]{3})\s*\((\d{3,4})\)\s*-\s*([A-Z]{3})\s*\((\d{3,4})\)")
_RE_REPORT = re.compile(r"report(?:ing)?\s*time\s*:?\s*(\d{3,4})", re.I)
_RE_BASE = re.compile(r"local base\s*\(([A-Z]{3})\)", re.I)
_RE_TITLE = re.compile(r"^\s*(\d{2,4})\s+([A-Z]{3})\s*[-/>\u2192]\s*([A-Z]{3})")
_RE_LOC_Z = re.compile(r"\((\d{3,4})Z\s*-\s*(\d{3,4})Z\)\s*([A-Z]{3})?", re.I)
_RE_ROUTE = re.compile(r"\b([A-Z]{3})\s*[-/>\u2192]+\s*([A-Z]{3})\b")

# Standby comes in two kinds and they are not interchangeable. Home standby is
# a day at home by the phone; airport standby is a shift at the field in
# uniform, with a drive home at the end. The wall should say which.
#
# easyJet writes airport standby as ADTY (airport duty). It contains none of
# the "sby" spellings, so it used to fall through every check and get picked up
# by the bare-route fallback as a phantom LGW-LGW "flight".
_RE_IATA = re.compile(r"\b([A-Z]{3})\b")
# A bare roster code: one short all-caps token, e.g. "ADTY", "D/O", "X". Used
# only to tell an unrecognised *code* from an unrecognised *event*, so the
# first can be kept and shown rather than silently dropped.
_RE_CODEISH = re.compile(r"^[A-Z][A-Z0-9/]{0,7}$")

# Which codes mean what now lives in ident/duty_codes.py, so an airline is
# added in one place and both parsers learn it at once.


def parse_ical(ics_text, base_iata: str = "", duty_gap_hours: float = 5.0,
               report_lead_min: int = 60, debrief_minutes: int = 30,
               debug: bool = False, show_codes=None) -> Roster:
    from icalendar import Calendar
    cal = Calendar.from_ical(ics_text)

    sector_items: list[tuple[Sector, Optional[dt.datetime]]] = []
    other_duties: list[Duty] = []
    discovered_base = base_iata
    raw = []

    for comp in cal.walk("VEVENT"):
        summary = str(comp.get("summary", "")).strip()
        desc = str(comp.get("description", "")).strip()
        location = str(comp.get("location", "")).strip()
        start = _to_utc(comp.get("dtstart"))
        end = _to_utc(comp.get("dtend")) or start
        raw.append({"summary": summary, "description": desc, "location": location,
                    "start": start, "end": end})

        bm = _RE_BASE.search(desc)
        if bm and not discovered_base:
            discovered_base = bm.group(1).upper()
        base = (bm.group(1).upper() if bm else discovered_base) or base_iata

        kind, payload = parse_event(summary, desc, location, start, end, base,
                                    show_codes=show_codes)
        if kind == "flight":
            sectors, report = payload
            for s in sectors:
                sector_items.append((s, report))
        elif kind == "standby":
            s_start, s_end, label, at_airport, station = payload
            other_duties.append(Duty(date=(s_start or start).date(),
                                     duty_type=DutyType.STANDBY, raw_code=label,
                                     standby_start=s_start, standby_end=s_end,
                                     at_airport=at_airport, location=station))
        elif kind in ("off", "training", "other"):
            date, label = payload
            typ = {"off": DutyType.DAY_OFF, "training": DutyType.TRAINING,
                   "other": DutyType.OTHER}[kind]
            other_duties.append(Duty(date=date, duty_type=typ, raw_code=label))

    roster = Roster(base=discovered_base or base_iata)
    roster.duties.extend(_group(sector_items, duty_gap_hours, report_lead_min,
                                debrief_minutes, base=discovered_base or base_iata))
    roster.duties.extend(other_duties)
    if debug:
        roster.__dict__["raw_events"] = raw
    return roster


def parse_event(summary, description, location, start, end, base, show_codes=None):
    """Pure field parser for one VEVENT. Returns (kind, payload).

    kind is one of: 'flight' -> ([Sector...], report_dt|None)
                    'standby' -> (start, end, label, at_airport, station)
                    'off'/'training'/'other' -> (date, label)
                    'skip' -> None
    """
    text = " ".join([summary, location, description])

    # A real flight is identified *first*, before any code matching runs.
    # Twelve duty codes are also live IATA airport codes — MED is Medina, SIM
    # is Simara, PAT is Patna — so a sector to one of them used to be read as
    # a private code and hidden as a day off. A duty with a flight number and
    # a printed schedule is a flight, whatever three letters are in it.
    flight_lines = _RE_FLIGHT_LINE.findall(description)
    title = _RE_TITLE.match(summary)

    if flight_lines or title:
        anchor = (start or end or dt.datetime.now(dt.timezone.utc))
        # Date in base-local terms so the local HHMM attach to the right day.
        local_date = base_local_to_utc(
            dt.datetime(anchor.year, anchor.month, anchor.day), base
        ).date() if False else anchor.astimezone(_base_tz(base)).date()

        rep_m = _RE_REPORT.search(description)
        report = _mk(local_date, rep_m.group(1), base) if rep_m else None

        sectors: list[Sector] = []
        prev = report
        if flight_lines:
            for no, dep, dep_t, arr, arr_t in flight_lines:
                std = _seq(local_date, dep_t, prev, base)
                sta = _seq(local_date, arr_t, std, base)
                sectors.append(Sector(flight_no=no, dep=dep, arr=arr, std=std, sta=sta))
                prev = sta
        else:
            # Fallback: route from title, times from LOCATION Zulu or DTSTART/END.
            no, dep, arr = title.group(1), title.group(2), title.group(3)
            zz = _RE_LOC_Z.search(location)
            if zz:
                std = _mk_z(local_date, zz.group(1))
                sta = _mk_z(local_date, zz.group(2))
                if sta < std:
                    sta += dt.timedelta(days=1)
            else:
                std, sta = start, end
            sectors.append(Sector(flight_no=no, dep=dep, arr=arr, std=std, sta=sta))
        return "flight", (sectors, report)

    # Not a flight. Private codes next — compassionate leave and the like are
    # shown as an ordinary day off and the real code is discarded rather than
    # stored — and before anything can read a route out of them.
    if _codes.matched_code(text) is not None:
        label = _codes.public_code(summary or text, show_codes)
        if label == _codes.PUBLIC_SUBSTITUTE:
            return "off", ((start or end).date(), _codes.PUBLIC_SUBSTITUTE)
        return "off", ((start or end).date(), (summary or label).strip())

    typ = _codes.classify(text)
    if typ is DutyType.STANDBY:
        airport = _codes.is_airport_standby(text)
        # The station is only meaningful for airport standby. Home standby is
        # at home, and printing a base code there would say the opposite.
        return "standby", (start, end, _standby_label(summary), airport,
                           _station(location, summary, base) if airport else "")
    if typ is DutyType.DAY_OFF:
        # WFTU and friends are rostering's wording for a day off; say so.
        return "off", ((start or end).date(), _codes.normalise(summary) or "D/O")
    if typ is DutyType.TRAINING:
        return "training", ((start or end).date(), summary or "TRAINING")
    if typ is DutyType.OTHER:
        # A recognised working day that is neither flying, standby nor
        # training — a union day. Shown as a duty carrying its own code.
        return "other", ((start or end).date(), (summary or "DUTY").strip())
    # Last-ditch: a bare route in the summary, with no flight number anywhere.
    #
    # This is a guess, so it is deliberately narrow. In particular a route from
    # an airport to itself is not a flight — it is a duty envelope, the shape
    # airport standby and other ground duties take. Accepting those created a
    # sector spanning the whole duty, which then won _airborne_sector() over the
    # real sectors and put "EZY---- LGW-LGW" on the wall for an entire trip.
    r = _RE_ROUTE.search(summary)
    if r and r.group(1) != r.group(2):
        return "flight", ([Sector(flight_no="----", dep=r.group(1), arr=r.group(2),
                                  std=start, sta=end)], None)
    if r:
        # Same airport both ends: a ground duty of some kind. Show it as one
        # rather than dropping it, so an unrecognised code is still visible.
        # Not flagged as airport standby - an unknown code is not evidence of
        # what the duty is, and "AIRPORT DUTY" would be a claim, not a label.
        return "standby", (start, end, _standby_label(summary, "DUTY"), False,
                           r.group(1).upper())
    # An unrecognised *code* is kept and shown as an unclassified duty. It used
    # to return "skip", which dropped the duty from the roster entirely: a
    # code Ident hadn't learned yet simply vanished, and the wall showed the
    # next duty instead with nothing to say anything was missing. Anything that
    # doesn't look like a roster code at all is still skipped, so a stray
    # personal entry in the same calendar can't take over a day.
    head = (summary or "").strip().split()
    if head and _RE_CODEISH.match(head[0]):
        return "other", ((start or end).date(), summary.strip())
    return "skip", None


def _standby_label(summary, fallback="STBY") -> str:
    """The code to print for a non-flying duty, with any route stripped out.

    AIMS writes airport standby as "ADTY LGW-LGW". Printing the summary
    verbatim would put "LGW-LGW" back on the wall by the back door - which is
    the one thing this duty must never look like.
    """
    label = _RE_ROUTE.sub("", summary or "").strip(" -/\u2013\u2192")
    return label or fallback


def _station(location, summary, base) -> str:
    """Which airport a ground duty happens at.

    LOCATION is either "(0555Z-0755Z) LGW" or a bare "LGW"; failing both, a
    same-airport route in the summary names it; failing that, the roster base.
    """
    zz = _RE_LOC_Z.search(location or "")
    if zz and zz.group(3):
        return zz.group(3).upper()
    m = _RE_IATA.search(location or "")
    if m:
        return m.group(1).upper()
    r = _RE_ROUTE.search(summary or "")
    if r and r.group(1) == r.group(2):
        return r.group(1).upper()
    return (base or "").upper()


def _group(items, gap_hours, report_lead, debrief, base=""):
    items = sorted(items, key=lambda it: it[0].std)
    duties: list[Duty] = []
    cur: list[tuple] = []
    gap = dt.timedelta(hours=gap_hours)

    def close(group):
        secs = [it[0] for it in group]
        reports = [it[1] for it in group if it[1]]
        rep = min(reports) if reports else None
        estimated = rep is None
        if estimated:
            rep = secs[0].std - dt.timedelta(minutes=report_lead)
        # The duty's date is the day it starts *where the pilot is*, not in UTC:
        # an 03:30 local departure from a UTC+4 base is 23:30Z the day before.
        _tz = _base_tz(base) if base else dt.timezone.utc
        return Duty(date=secs[0].std.astimezone(_tz).date(),
                    duty_type=DutyType.FLY, report=rep, report_estimated=estimated,
                    duty_end=secs[-1].sta + dt.timedelta(minutes=debrief),
                    sectors=secs)

    for it in items:
        if cur and it[0].std - cur[-1][0].sta > gap:
            duties.append(close(cur))
            cur = []
        cur.append(it)
    if cur:
        duties.append(close(cur))
    return duties


# --- time helpers ------------------------------------------------------------

def _base_tz(base):
    from ..timezones import tz_for_airport
    return tz_for_airport(base)


def _pad(t: str) -> tuple[int, int]:
    t = t.zfill(4)
    return int(t[:2]), int(t[2:])


def _mk(date, hhmm, base) -> dt.datetime:
    h, m = _pad(hhmm)
    return base_local_to_utc(dt.datetime(date.year, date.month, date.day, h, m), base)


def _mk_z(date, hhmm) -> dt.datetime:
    h, m = _pad(hhmm)
    return dt.datetime(date.year, date.month, date.day, h, m, tzinfo=dt.timezone.utc)


def _seq(date, hhmm, not_before, base) -> dt.datetime:
    h, m = _pad(hhmm)
    naive = dt.datetime(date.year, date.month, date.day, h, m)
    utc = base_local_to_utc(naive, base)
    while not_before is not None and utc < not_before:
        naive += dt.timedelta(days=1)
        utc = base_local_to_utc(naive, base)
    return utc


def _to_utc(prop) -> Optional[dt.datetime]:
    if prop is None:
        return None
    value = getattr(prop, "dt", prop)
    if isinstance(value, dt.datetime):
        if value.tzinfo is None:
            value = value.replace(tzinfo=dt.timezone.utc)
        return value.astimezone(dt.timezone.utc)
    if isinstance(value, dt.date):
        return dt.datetime(value.year, value.month, value.day, tzinfo=dt.timezone.utc)
    return None
