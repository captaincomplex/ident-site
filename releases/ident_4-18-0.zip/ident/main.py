"""Ident daemon.

Each tick it recomputes the current state and renders it. While you're airborne
it polls the live tracker (at most every poll_seconds) and merges actual times /
ETA into the active sector so the wall and the home estimate track reality.

Run on the Pi:
    python -m ident.main              # renders to configured output + web UI
    python -m ident.main --no-web     # headless

The web control panel runs in a background thread on port 8080 by default.
"""
from __future__ import annotations

import argparse
import datetime as dt
import os
import threading
import time
import traceback

from .config import Config, ROSTER_PATH, build_renderer, build_tracker, load_roster
from .render.presenter import present
from .state_engine import DutyState, compute_view
from .tracking.base import poll_interval, update_sector


def _start_web(port: int):
    """Serve the control panel.

    Uses waitress - a production WSGI server - rather than Flask's development
    server, which is single-threaded and explicitly not meant to face a network.
    Falls back to Flask's server so an existing install without waitress keeps
    working after an update.
    """
    from .web.app import create_app
    app = create_app()

    def _serve():
        try:
            from waitress import serve
            serve(app, host="0.0.0.0", port=port, threads=8, ident="Ident")
        except ImportError:
            print("[ident] waitress not installed - falling back to the "
                  "development server (run: pip install waitress)")
            app.run(host="0.0.0.0", port=port, debug=False, use_reloader=False)

    threading.Thread(target=_serve, daemon=True).start()


def _roster_if_changed(state):
    """Reload roster.json only when it has actually changed.

    The daemon used to reload it every tick. Nothing serialises FlightStatus
    (see models._duty_to_dict), so every reload threw away the live ETA the
    tracker had just fetched: the real landing time appeared for one
    30-second tick and then reverted to the schedule until the next poll, six
    to twenty-four minutes later. On an on-time flight the live and scheduled
    times are the same, so nothing looked wrong — which is why this survived
    so long. It only shows itself on a delay, which is the one occasion the
    whole feature exists for.
    """
    try:
        mtime = os.path.getmtime(ROSTER_PATH)
    except OSError:
        mtime = None
    if state["roster"] is None or mtime != state["roster_mtime"]:
        state["roster"] = load_roster()
        state["roster_mtime"] = mtime
    return state["roster"]


def _release_age_hours(info) -> "float | None":
    ts = (info.get("released") or "").strip()
    if not ts:
        return None
    try:
        when = dt.datetime.fromisoformat(ts.replace("Z", "+00:00"))
    except ValueError:
        return None
    if when.tzinfo is None:
        when = when.replace(tzinfo=dt.timezone.utc)
    return (dt.datetime.now(dt.timezone.utc) - when).total_seconds() / 3600.0


def should_auto_install(cfg, info, vm_state, age_hours) -> bool:
    """Whether to install an update without being asked.

    Two conditions, both deliberate:

    * the release must have been published for at least
      ``auto_update_min_age_hours`` — so a bad release sits on the author's own
      wall for a few days before it can reach a customer's kitchen. The
      developer page can set that to zero to take updates the moment they
      appear.
    * the wall must not be mid-duty. Installing restarts the service, and the
      one moment that must never happen is while a household is watching for a
      landing time.
    """
    if not getattr(cfg, "auto_update", True):
        return False
    if not (info.get("update_available") and info.get("url")):
        return False
    if vm_state not in (DutyState.DAY_OFF, DutyState.BETWEEN_DUTIES, DutyState.NO_ROSTER):
        return False
    gate = max(0, int(getattr(cfg, "auto_update_min_age_hours", 72) or 0))
    if gate and (age_hours is None or age_hours < gate):
        return False
    return True


# States in which a home time is on the wall, and therefore the only states in
# which a live drive time is worth paying for.
_COMMUTE_STATES = (DutyState.IN_FLIGHT, DutyState.TURNAROUND, DutyState.POST_DUTY)


def _maps_ready(cfg) -> bool:
    """Everything the Routes API call needs, present and switched on."""
    return bool(getattr(cfg, "use_maps_commute", False)
                and cfg.google_maps_api_key
                and cfg.base_lat is not None and cfg.base_lng is not None
                and cfg.home_lat is not None and cfg.home_lng is not None)


def _live_commute(cfg, vm, state) -> int:
    """The commute to use this tick: the live drive time if we have a fresh one,
    otherwise the slider. Never raises, never blocks for long."""
    slider = int(cfg.commute_minutes or 0)
    if vm.state not in _COMMUTE_STATES:
        state["commute_live"] = 0          # don't carry one duty's traffic into the next
        return slider
    if not _maps_ready(cfg):
        return slider
    every = max(1, int(getattr(cfg, "maps_refresh_minutes", 15) or 15)) * 60
    if time.time() - state.get("last_maps", 0) >= every:
        state["last_maps"] = time.time()
        try:
            from .maps import drive_minutes
            mins = drive_minutes(cfg.google_maps_api_key,
                                 (cfg.base_lat, cfg.base_lng),
                                 (cfg.home_lat, cfg.home_lng),
                                 depart_at=vm.home.commute_start if vm.home else None,
                                 timeout=5.0)
            if mins:
                state["commute_live"] = int(mins)
                print(f"[ident] live commute {mins} min (slider {slider})")
        except Exception as e:
            print(f"[ident] maps lookup failed: {type(e).__name__}: {e}")
    return int(state.get("commute_live") or slider)


def _tick(state, renderer, tracker):
    """One pass: work out what the wall should say, and say it."""
    cfg = Config.load()                          # pick up web edits live
    _apply = getattr(renderer, "apply_config", None)
    if _apply:                                   # ...and get them to the wall
        try:
            _apply(cfg)
        except Exception as e:
            print(f"[ident] could not apply config to the renderer: "
                  f"{type(e).__name__}: {e}")

    if cfg.ical_url and cfg.ical_refresh_minutes and \
       (time.time() - state["last_ical"] >= cfg.ical_refresh_minutes * 60):
        try:
            from .config import refresh_from_ical
            n = refresh_from_ical(cfg)
            if n is not None:
                print(f"[ident] iCal auto-refresh: {n} duties")
        except Exception as e:
            # Deliberately not str(e): requests puts the full URL in its
            # exception text, and the iCal URL is a bearer token for the whole
            # roster. This line ends up in the journal, and the journal ends up
            # in the diagnostics export the customer emails to support.
            print(f"[ident] iCal refresh failed: {type(e).__name__}")
        state["last_ical"] = time.time()

    # No network? Put up our own hotspot so it can be set up from a phone.
    try:
        from . import onboarding as _ob
        if _ob.is_online():
            state["offline_since"] = None
            if _ob.ap_active():
                print("[ident] back online - stopping setup hotspot")
                _ob.stop_ap()
        elif not _ob.ap_active():
            if state["offline_since"] is None:
                state["offline_since"] = time.time()
            elif time.time() - state["offline_since"] >= cfg.hotspot_after_seconds > 0:
                ok, info = _ob.start_ap()
                print(f"[ident] offline - setup hotspot '{info}'" if ok
                      else f"[ident] could not start hotspot: {info}")
    except Exception as e:
        print(f"[ident] onboarding check failed: {type(e).__name__}: {e}")

    if cfg.update_check_hours and (time.time() - state["last_upd"] >= cfg.update_check_hours * 3600):
        try:
            from .updates import check as _check
            state["update_info"] = _check(cfg.update_repo)
            if state["update_info"].get("update_available"):
                print(f"[ident] update available: {state['update_info']['latest']} "
                      f"(running {state['update_info']['current']})")
        except Exception as e:
            print(f"[ident] update check failed: {type(e).__name__}: {e}")
        state["last_upd"] = time.time()

    roster = _roster_if_changed(state)
    now = dt.datetime.now(dt.timezone.utc)

    # Developer preview: pretend a chosen duty is happening right now. The
    # override carries its own expiry, so this can't strand the wall.
    _dev = None
    try:
        from .devtools import override_view
        _dev = override_view(cfg)
    except Exception:
        _dev = None
    if _dev:
        roster, now = _dev

    vm = compute_view(roster, now, debrief_minutes=cfg.debrief_minutes,
                      walk_minutes=cfg.walk_minutes,
                      commute_minutes=cfg.commute_minutes, cfg=cfg)

    # Poll live tracking only while airborne, and only for the sector the
    # state engine says is airborne.
    if vm.state == DutyState.IN_FLIGHT and cfg.tracker != "none" and not _dev:
        _eta = vm.active_sector.effective_arrival() if vm.active_sector else None
        if time.time() - state["last_poll"] >= poll_interval(cfg.poll_seconds, _eta, now):
            try:
                if update_sector(vm.active_sector, tracker, cfg.airline_iata,
                                 cfg.airline_icao, now):
                    # Live data landed: recompute so the new ETA reaches the wall
                    # on this tick rather than the next one.
                    vm = compute_view(roster, now, debrief_minutes=cfg.debrief_minutes,
                                      walk_minutes=cfg.walk_minutes,
                                      commute_minutes=cfg.commute_minutes, cfg=cfg)
            except Exception as e:
                print(f"[ident] tracker error: {type(e).__name__}: {e}")
            state["last_poll"] = time.time()

    # Optional live drive time. Off by default; see ident/maps.py for why the
    # rules are what they are.
    _commute = cfg.commute_minutes if _dev else _live_commute(cfg, vm, state)

    from .config import transfer_minutes_for
    _tr = transfer_minutes_for(cfg, vm)
    if _tr or _commute != cfg.commute_minutes:
        vm = compute_view(roster, now, debrief_minutes=cfg.debrief_minutes,
                          walk_minutes=cfg.walk_minutes,
                          commute_minutes=_commute,
                          transfer_minutes=_tr, cfg=cfg)

    if should_auto_install(cfg, state.get("update_info") or {}, vm.state,
                           _release_age_hours(state.get("update_info") or {})):
        try:
            from .updates import install, _sha256_from_notes
            info = state["update_info"]
            print(f"[ident] installing {info.get('latest')} automatically")
            res = install(info["url"], _sha256_from_notes(info.get("notes", "")))
            print("[ident] update installed" if res.get("ok")
                  else f"[ident] auto-update failed: {res.get('error')}")
            state["update_info"] = {}
        except Exception as e:
            print(f"[ident] auto-update failed: {type(e).__name__}: {e}")

    screen = present(vm, tz_mode=cfg.tz_mode, flight_prefix=cfg.display_prefix,
                     iata=cfg.airline_iata, now=now,
                     stamp_minutes=(cfg.time_stamp_minutes if cfg.show_time_stamp else 0))
    try:
        renderer.show(screen)
    except Exception as e:
        print(f"[ident] render error: {type(e).__name__}: {e}")
    from . import runtime
    runtime.ticked()


def run(enable_web: bool = True, port: int = 8080, tick_seconds: int = 30):
    cfg = Config.load()
    try:
        from .auth import check_password_reset
        if check_password_reset(cfg):
            cfg = Config.load()
    except Exception as e:
        print(f"[ident] password-reset check failed: {type(e).__name__}: {e}")
    try:
        from .config import adopt_attached_panel
        note = adopt_attached_panel()
        if note:
            print(f"[ident] {note}")
            cfg = Config.load()
    except Exception as e:
        print(f"[ident] panel probe failed: {type(e).__name__}: {e}")
    renderer = build_renderer(cfg)
    tracker = build_tracker(cfg)
    try:
        from . import geo
        threading.Thread(target=geo.prefetch, daemon=True).start()
    except Exception:
        pass
    if enable_web:
        _start_web(port)
        print(f"[ident] control panel on http://0.0.0.0:{port}")

    state = {"last_poll": 0.0, "last_ical": 0.0, "last_upd": 0.0,
             "last_maps": 0.0, "commute_live": 0,
             "offline_since": None, "update_info": {},
             "roster": None, "roster_mtime": None}

    from . import __version__
    print(f"[ident] v{__version__} started · output={cfg.renderer} · tracker={cfg.tracker}")
    while True:
        try:
            _tick(state, renderer, tracker)
        except KeyboardInterrupt:
            raise                       # Ctrl+C still stops it, as it should
        except BaseException as e:
            # This loop must never exit. The web panel runs in a thread of this
            # same process, so a daemon that dies takes away the owner's only
            # means of fixing whatever killed it — and systemd's restart
            # limiter eventually stops trying, leaving a frozen screen and no
            # way in short of an SD card reader.
            #
            # BaseException, not Exception, and the reason is real: on 10 Sep a
            # Pi 3A+ hit gpiodevice's "Woah there, some pins we need are in
            # use!" — which is a friendly message followed by sys.exit(). That
            # raises SystemExit, which does not inherit from Exception, so this
            # guard let it straight through and the whole process died. The
            # control panel went with it, so the one screen that could have
            # explained the problem was the thing the problem took away.
            print(f"[ident] tick failed, carrying on: {type(e).__name__}: {e}")
            traceback.print_exc()
        time.sleep(tick_seconds)


def main():
    ap = argparse.ArgumentParser(description="Ident daemon")
    ap.add_argument("--no-web", action="store_true", help="disable the web panel")
    ap.add_argument("--port", type=int, default=8080)
    ap.add_argument("--tick", type=int, default=30, help="render interval seconds")
    ap.add_argument("--set-password", action="store_true",
                    help="set (or clear) the web panel login, then exit")
    args = ap.parse_args()
    if args.set_password:
        import getpass
        from .auth import hash_password
        cfg = Config.load()
        user = input(f"Username [{cfg.auth_user or 'pilot'}]: ").strip() or (cfg.auth_user or "pilot")
        pw = getpass.getpass("Password (blank to disable login): ")
        if pw and pw != getpass.getpass("Confirm password: "):
            print("Passwords did not match."); return
        cfg.auth_user = user
        cfg.auth_password_hash = hash_password(pw) if pw else ""
        cfg.save()
        print(f"Login {'enabled for user ' + user if pw else 'disabled'}.")
        return
    try:
        run(enable_web=not args.no_web, port=args.port, tick_seconds=args.tick)
    except KeyboardInterrupt:
        print("\n[ident] stopped")


if __name__ == "__main__":
    main()
