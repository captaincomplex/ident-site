"""What the running daemon is doing right now, for the developer page.

Deliberately in memory and never written to disk. The question these values
answer is "is this process still drawing the wall, and what is it drawing" —
and a figure that survived a restart would answer it wrongly, which is the
exact failure this exists to expose. A wall once showed a three-day-old duty
with every light on, because e-ink holds its picture with no power at all and
nothing anywhere said when it had last been drawn.
"""
from __future__ import annotations

import datetime as dt

HEARTBEAT: dict = {
    "tick_at": None,        # the daemon completed a pass
    "paint_at": None,       # the panel was actually repainted
    "style": "",            # what the renderer is drawing
    "photo_override": False,  # ...or would be, but the day-off photo is on top
}


def _now() -> dt.datetime:
    return dt.datetime.now(dt.timezone.utc)


def ticked() -> None:
    HEARTBEAT["tick_at"] = _now()


def showing(style: str, photo_override: bool) -> None:
    """What the renderer just drew, whether or not the panel accepted it."""
    HEARTBEAT["style"] = style
    HEARTBEAT["photo_override"] = bool(photo_override)


def painted() -> None:
    """The panel genuinely repainted — e-ink only does so when the picture
    changes, so this is minutes or hours behind tick_at and should be."""
    HEARTBEAT["paint_at"] = _now()


def snapshot() -> dict:
    out = dict(HEARTBEAT)
    for k in ("tick_at", "paint_at"):
        out[k] = out[k].isoformat() if out[k] else None
    return out
