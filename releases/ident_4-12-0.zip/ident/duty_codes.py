"""Duty codes, in one place — including the ones that shouldn't be displayed.

Some roster codes say something the rest of the room has no business reading off
a wall. Compassionate leave is the obvious one: the board is in a kitchen, and a
visitor shouldn't learn that a bereavement is in progress because a four-letter
code appeared on it. Resignation is another — that is news you deliver yourself,
in your own order, not something a wall breaks to whoever walks past.

Every code in ``DISCREET`` is **hidden by default** and shown as an ordinary day
off. The owner can reveal any of them individually during setup or later in
settings; nothing is revealed without being asked for.

Hiding happens **at parse time**, and the original code is not kept. That is
deliberate: a code that is never stored cannot leak through a display style added
in a future version, a diagnostics export, or a screenshot sent to support. The
cost is that revealing a code only affects rosters read after the change, which
is why the panel re-reads the feed when the setting is saved.

Both parsers import from here, so adding an airline's codes is one edit.
"""
from __future__ import annotations

import re

from .models import DutyType

_WORD = re.compile(r"[A-Z][A-Z0-9/]*")

PUBLIC_SUBSTITUTE = "D/O"

# code -> (label shown in the settings checklist, why it might matter)
DISCREET: dict[str, tuple[str, str]] = {
    # Bereavement and family
    "COMP":  ("Compassionate leave", "A bereavement or family crisis in progress."),
    "CMPU":  ("Compassionate leave, unpaid", "As above."),
    "MAT":   ("Maternity leave", "A pregnancy you may not have announced."),
    "PAT":   ("Paternity leave", "As above."),
    "PARL":  ("Parental leave", "As above."),
    # Health
    "SICK":  ("Sick", "Your health is nobody else's business."),
    "S/L":   ("Sick leave", "As above."),
    "MED":   ("Medical", "A routine medical and a licence problem look identical."),
    "LOL":   ("Loss of licence", "Career-threatening, and rarely settled news."),
    # Employment
    "RESN":  ("Resigned", "News you should deliver yourself, in your own order."),
    "TERM":  ("Termination", "As above, and worse."),
    "SUSP":  ("Suspended", "An allegation is not a finding."),
    "DISC":  ("Disciplinary", "As above."),
    "GRV":   ("Grievance", "Yours or someone else's — either way, private."),
    # Ambiguous by nature
    "MEET":  ("Meeting", "A management meeting and a disciplinary look the same."),
    "INT":   ("Interview", "A command board, or a job elsewhere."),
    "SOC":   ("Subject to operational clearance", "A request that may still be refused."),
    "UNPD":  ("Unpaid leave", "Often financial, occasionally not."),
}

# Wording that means the same thing when an airline spells it out in the summary.
DISCREET_PHRASES = (
    "compassionate", "bereavement", "subject to operational clearance",
    "parental leave", "maternity", "paternity", "sick leave", "resigned",
    "resignation", "suspended", "disciplinary", "grievance", "loss of licence",
    "loss of license", "termination",
)

# Which phrase belongs to which code, so revealing "SICK" also reveals an event
# that spells out "sick leave" rather than using the code.
_PHRASE_CODE = {
    "compassionate": "COMP", "bereavement": "COMP",
    "subject to operational clearance": "SOC",
    "parental leave": "PARL", "maternity": "MAT", "paternity": "PAT",
    "sick leave": "SICK", "resigned": "RESN", "resignation": "RESN",
    "suspended": "SUSP", "disciplinary": "DISC", "grievance": "GRV",
    "loss of licence": "LOL", "loss of license": "LOL", "termination": "TERM",
}

# Codes that are useful on the wall and carry nothing personal. Listed so the
# settings page can say plainly what is *not* being hidden.
ALWAYS_SHOWN = {
    "D/O": "Day off", "OFF": "Day off", "WFTU": "Work-free time unit",
    "AL": "Annual leave", "LVE": "Leave",
    "ADTY": "Airport standby", "ESBY": "Standby (home)", "LSBY": "Late standby",
    "ASBY": "Airport standby", "HSBY": "Home standby", "PSBE": "Standby",
    "STBY": "Standby", "SBY": "Standby",
    "SIM": "Simulator", "FTGD": "Ground training", "GS": "Ground school",
    "LPC": "Licence proficiency check", "OPC": "Operator proficiency check",
    "OJT": "Line training", "CRM": "CRM course",
}

# Codes that mean "a day off" and should simply say so. WFTU is a work-free
# time unit — rostering's word for a day off, not something a household needs
# to decode off a wall. Annual leave keeps its own label because "I'm on leave"
# is genuinely different information from "I'm not working today".
SAME_AS_DAY_OFF = {"WFTU", "DO", "OFF", "REST", "RD", "X"}


def normalise(code: str) -> str:
    """The label to display for a non-flying code.

    Matches on tokens, so "WFTU" and "WFTU Work free time unit" both come out
    as a plain day off — airlines are inconsistent about whether the summary is
    the bare code or the code plus its expansion.
    """
    raw = (code or "").strip()
    if not raw:
        return raw
    if raw.upper() in SAME_AS_DAY_OFF:
        return PUBLIC_SUBSTITUTE
    toks = _WORD.findall(raw.upper())
    return PUBLIC_SUBSTITUTE if (toks and toks[0] in SAME_AS_DAY_OFF) else raw


OFF_CODES = {"D/O", "DO", "OFF", "WFTU", "AL", "ANNUAL LEAVE", "LVE", "REST"}
STANDBY_CODES = {"PSBE", "ESBY", "LSBY", "ASBY", "HSBY", "STBY", "SBY",
                 "ADTY", "APTD"}
TRAINING_CODES = {"FTGD", "SIM", "GS", "OJT", "LPC", "OPC", "CRM"}

def _tokens(text: str) -> set[str]:
    return set(_WORD.findall((text or "").upper()))


def matched_code(text: str) -> str | None:
    """Which private code this duty is, or None if it isn't one.

    Codes are matched on whole tokens, never substrings: "COMP" must not be
    found inside "COMPLETED", and "MED" must not match "MEDITERRANEAN".
    """
    low = (text or "").lower()
    for phrase, code in _PHRASE_CODE.items():
        if phrase in low:
            return code
    hit = _tokens(text) & set(DISCREET)
    if hit:
        # Deterministic when a summary somehow contains two.
        return sorted(hit)[0]
    return None


def is_discreet(text: str, show: "set[str] | list[str] | None" = None) -> bool:
    """Should this duty be shown as a plain day off?

    ``show`` is the set of codes the owner has chosen to reveal.
    """
    code = matched_code(text)
    if code is None:
        return False
    allowed = {c.upper() for c in (show or ())}
    return code not in allowed


def public_code(raw: str, show=None) -> str:
    """What may be shown. Hidden codes become an ordinary day off."""
    return PUBLIC_SUBSTITUTE if is_discreet(raw, show) else (raw or "")


def classify(text: str, show=None) -> DutyType | None:
    """Duty type from a code or summary, or None if it isn't recognised."""
    if matched_code(text) is not None:
        # Whether or not it's revealed, these are days you aren't flying.
        return DutyType.DAY_OFF
    toks = _tokens(text)
    if toks & OFF_CODES:
        return DutyType.DAY_OFF
    if toks & STANDBY_CODES:
        return DutyType.STANDBY
    if toks & TRAINING_CODES:
        return DutyType.TRAINING
    return None


def checklist() -> list[tuple[str, str, str]]:
    """(code, label, why) for the settings UI, in a sensible reading order."""
    return [(c, DISCREET[c][0], DISCREET[c][1]) for c in DISCREET]
